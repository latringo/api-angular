import { environment } from "@env/environment";
import { enableProdMode } from "@angular/core";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";

import { AppModule } from "./app/app.module";
import { getBaseUrl } from "@env/baseUrl";

if (environment.production) {
  enableProdMode();
}

// https://stackoverflow.com/a/41341177/2349252
const deps: any[] = [];
let providers: any;

providers = [{ provide: "BASE_URL", useFactory: getBaseUrl, deps }];

platformBrowserDynamic(providers)
  .bootstrapModule(AppModule)
  .catch((err) => console.error(err));
