import {
  HttpEvent,
  HttpHandler,
  HttpHeaders,
  HttpInterceptor,
  HttpRequest,
  HttpErrorResponse,
} from "@angular/common/http";
import { Injectable, Inject } from "@angular/core";
import { Router } from "@angular/router";
import { environment } from "@env/environment";
import { from, Observable } from "rxjs";
import { tap } from "rxjs/operators";
import { AuthenticationService } from "src/app/auth";

// example from https://app.pluralsight.com/library/courses/openid-and-oauth2-securing-angular-apps/exercise-files
@Injectable({
  providedIn: "root",
})
export class AuthInterceptorService implements HttpInterceptor {
  constructor(
    private _authService: AuthenticationService,
    private _router: Router
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (
      req.url.startsWith(environment.apiUrl) ||
      req.url.startsWith(environment.openIdConnectSettings.authority)
    ) {
      // if (req.url?.startsWith(environment.openIdConnectSettings.authority)) {

      return from(
        this._authService.getAccessToken().then((token) => {
          const headers = new HttpHeaders({
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          });

          const authReq = req.clone({ headers });

          return next
            .handle(authReq)
            .pipe(
              tap(
                (_) => {},
                (error) => {
                  const respError = error as HttpErrorResponse;
                  if (respError && respError.status === 401) {
                    this._router.navigate(["/unauthorized"]);
                  }
                }
              )
            )
            .toPromise();
        })
      );
    } else {
      return next.handle(req);
    }
  }
}
