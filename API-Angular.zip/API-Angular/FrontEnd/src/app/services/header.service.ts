import { Injectable } from '@angular/core'
import { BehaviorSubject } from 'rxjs'

@Injectable({
    providedIn: 'root',
})
export class HeaderService {
    pageTitle: string = 'Dashboard'
    private titleSource = new BehaviorSubject(this.pageTitle)
    currentTitle = this.titleSource.asObservable()

    pageDescription: string = ''
    private descriptionSource = new BehaviorSubject(this.pageDescription)
    currentPageDescription = this.descriptionSource.asObservable()

    constructor() {}

    public setTitle(title: string) {
        this.titleSource.next(title)
    }

    public setPageDescription(description: string) {
        this.descriptionSource.next(description)
    }
}
