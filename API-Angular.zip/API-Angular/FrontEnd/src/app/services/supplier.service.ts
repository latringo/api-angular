import { Injectable } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { HttpService } from '@core/http/http.service'
import { ConfigService } from '@app/services/config.service'
import { Supplier } from '../models/supplier'
import { Observable } from 'rxjs'

@Injectable({
    providedIn: 'root',
})
export class SupplierService {
    apiUrl: string
    suppliers: Supplier[]

    constructor(
        private httpClient: HttpService,
        private configService: ConfigService
    ) {
        this.apiUrl = configService.getApiUrl() + 'suppliers'
    }

    getSuppliers() {
        const businessId = 6
        const apiUrl = this.apiUrl + '/bybusiness/' + businessId
        return this.httpClient.get<Supplier[]>(apiUrl).subscribe((data) => {
            this.suppliers = data
        })
    }

    getSupplier(supplierId: number) {
        const apiUrl = this.apiUrl + '/' + supplierId
        this.httpClient.get<Supplier>(apiUrl).subscribe((data) => {
            return data
        })
    }

    createSupplier(supplier: Supplier): Observable<Supplier> {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}`
        return this.httpClient.post<Supplier>(url, supplier, {
            headers: urlHeaders,
        })
    }

    updateSupplier(supplier: Supplier): Observable<Supplier> {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}/${supplier.id}`
        return this.httpClient.put<Supplier>(url, JSON.stringify(supplier), {
            headers: urlHeaders,
        })
    }

    deleteSupplier(supplier: Supplier, formValue: any): Observable<Supplier> {
        if (!formValue.itemId) {
            formValue.itemId = supplier.id
        }

        formValue.softDelete = true

        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}/softdelete/${formValue.itemId}`
        return this.httpClient.put<Supplier>(url, JSON.stringify(formValue), {
            headers: urlHeaders,
        })
    }
}
