import { Injectable } from '@angular/core'
import { HttpHeaders } from '@angular/common/http'
import { HttpService } from '@app/@core/http/http.service'
import { ConfigService } from '@app/services/config.service'
import { Observable } from 'rxjs'
import { ItemLocation } from '@app/models/itemlocation'
import { Business } from '@app/models/business'

@Injectable({
    providedIn: 'root',
})
export class ItemLocationService {
    apiUrl: string
    business: Business

    constructor(
        private http: HttpService,
        private configService: ConfigService
    ) {
        this.configService.business.subscribe((data) => {
            this.business = data
        })
        this.apiUrl = configService.getApiUrl() + 'itemlocations'
    }

    getItemLocations(): Observable<ItemLocation[]> {
        const businessId = 6
        const apiUrl = this.apiUrl + '/bybusiness/' + businessId
        return this.http.get<ItemLocation[]>(apiUrl)
    }

    getItemLocation(itemLocationId: number) {
        const apiUrl = this.apiUrl + '/' + itemLocationId
        return this.http.get<ItemLocation>(apiUrl)
    }

    createItemLocation(itemLocation: ItemLocation): Observable<ItemLocation> {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}`
        return this.http.post<ItemLocation>(url, itemLocation, {
            headers: urlHeaders,
        })
    }

    updateItemLocation(itemLocation: ItemLocation): Observable<ItemLocation> {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}/${itemLocation.id}`
        return this.http.put<ItemLocation>(url, JSON.stringify(itemLocation), {
            headers: urlHeaders,
        })
    }
}
