import { Inject, Injectable } from '@angular/core'

// import {ItemService} from "@app/services/item.service";
import { ItemLocationService } from '@app/services/item-location.service'
import { SupplierService } from '@app/services/supplier.service'
import { CategoryService } from '@app/services/category.service'
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogConfig,
    MatDialogRef,
} from '@angular/material/dialog'
import { Observable } from 'rxjs'
import { ModalComponent } from '@app/components/modal/modal.component'

@Injectable({
    providedIn: 'root',
})
export class ModalService {
    constructor(
        // private itemService: ItemService,
        private itemLocationService: ItemLocationService,
        private supplierService: SupplierService,
        private categoryService: CategoryService,
        public dialog: MatDialog,
        private dialogRef: MatDialogRef<ModalComponent>,
        @Inject(MAT_DIALOG_DATA) public data: MatDialogConfig
    ) {}

    openDeleteDialog(data: MatDialogConfig): Observable<any> {
        const dialogRef = this.dialog.open(ModalComponent, { data })
        return dialogRef.afterClosed()
    }
}
