import { Injectable } from '@angular/core'
import { BehaviorSubject, Subscription } from 'rxjs'

import { DataService } from '@app/services/data.service'
import { CommonService } from '@app/services/common.service'

import { SelectItem } from 'primeng/api'
import { Item } from '@app/models/item'
import { Category } from '@app/models/category'
import { ItemLocation } from '@app/models/itemlocation'
import { Supplier } from '@app/models/supplier'
import { UnitOfMeasure } from '@app/models/unitofmeasure'

@Injectable({
    providedIn: 'root',
})
export class InventoryService {
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initializedSubscribe = this._initialized.asObservable()
    private initializedSubscription: Subscription
    initialized: boolean = false

    private _inventoryItems = new BehaviorSubject<Item[]>([])
    readonly inventoryItems = this._inventoryItems.asObservable()

    itemsInitialized: boolean = false
    shoppingListItemsInitialized: boolean = false
    categoriesInitialized: boolean = false
    suppliersInitialized: boolean = false
    itemLocationsInitialized: boolean = false
    unitsOfMeasureInitialized: boolean = false

    public inventoryItem: Item
    public categories: Category[]
    public category: Category
    public categoryOptions: SelectItem[]
    public itemLocation: ItemLocation
    public itemLocations: ItemLocation[]
    public itemLocationOptions: SelectItem[]
    public supplier: Supplier
    public suppliers: Supplier[]
    public supplierOptions: SelectItem[]
    public unitOfMeasure: UnitOfMeasure
    public unitsOfMeasure: UnitOfMeasure[]
    public unitsOfMeasureOptions: SelectItem[]

    constructor(
        private dataService: DataService,
        private commonService: CommonService
    ) {
        this.initializedSubscription = this.initializedSubscribe.subscribe(
            (data) => {
                this.initialized = data
                if (!data) {
                    this.initialize()
                }
            }
        )
    }

    ngOnDestroy() {
        this.initializedSubscription.unsubscribe()
    }

    initialize() {
        this.categories = this.dataService.categories
        this.categoryOptions = this.commonService.mapItemsToSelect(
            this.categories
        )

        this.suppliers = this.dataService.suppliers
        this.supplierOptions = this.commonService.mapItemsToSelect(
            this.suppliers
        )

        // this.dataService.itemLocations.subscribe((data) => {
        //     this.itemLocations = data
        //     this.itemLocationOptions = this.commonService.mapItemsToSelect(
        //         this.itemLocations
        //     )
        //     this.itemLocationsInitialized = true
        //     this.checkInitialized()
        // })

        // this.dataService.unitsOfMeasure.subscribe((data) => {
        //     this.unitsOfMeasure = data
        //     this.unitsOfMeasureOptions = this.commonService.mapItemsToSelect(
        //         this.unitsOfMeasure
        //     )
        //     this.unitsOfMeasureInitialized = true
        //     this.checkInitialized()
        // })

        // this.dataService.items.subscribe((data) => {
        //     this._inventoryItems.next(data)
        //     this.itemsInitialized = true
        //     this.checkInitialized()
        // })
    }

    // checkInitialized() {
    //     let initialized =
    //         this.categoriesInitialized &&
    //         this.suppliersInitialized &&
    //         this.itemLocationsInitialized &&
    //         this.unitsOfMeasureInitialized &&
    //         this.itemsInitialized

    //     this._initialized.next(initialized)
    // }
}
