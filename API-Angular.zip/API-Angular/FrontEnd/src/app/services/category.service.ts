import { Injectable } from '@angular/core'
import { HttpHeaders } from '@angular/common/http'
import { HttpService } from '@core/http/http.service'
import { ConfigService } from '@app/services/config.service'
import { BehaviorSubject, Observable } from 'rxjs'
import { Category } from '@app/models/category'

@Injectable({
    providedIn: 'root',
})
export class CategoryService {
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initialized = this._initialized.asObservable()

    private _categories = new BehaviorSubject<Category[]>([])
    readonly categories = this._categories.asObservable()

    public currentCategory: Category
    apiUrl: string
    businessId = 6

    constructor(
        private httpClient: HttpService,
        private configService: ConfigService
    ) {
        this.configService.initialized.subscribe((data) => {
            if (data) {
                // this.initialize();
            }
        })
    }

    initialize() {
        this.apiUrl = this.configService.getApiUrl() + 'categories'
        this.getCategories().subscribe((data) => {
            this._categories.next(data)
            this._initialized.next(true)
        })
    }

    getCategories() {
        const apiUrl = this.apiUrl + '/bybusiness/' + this.businessId
        return this.httpClient.get<Category[]>(apiUrl)
    }

    // getCategory(categoryId): Observable<Category> {
    //   const apiUrl = this.apiUrl + '/' + categoryId;
    //   return this.httpClient.get<Category>(apiUrl);
    // }

    createItem(currentCategory: Category, itemForm: any): Observable<string> {
        const item = itemForm
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}`
        return this.httpClient.post<string>(url, item, { headers: urlHeaders })
    }

    updateCategory(currentItem: Category, formValue: any): Observable<string> {
        if (!formValue.itemId) {
            formValue.itemId = currentItem.id
        }

        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}/${formValue.itemId}`
        return this.httpClient.put<string>(url, JSON.stringify(formValue), {
            headers: urlHeaders,
        })
    }

    deleteItem(data: any, formValue: any): Observable<Category> {
        if (!formValue.itemId) {
            formValue.itemId = data.itemId
        }

        formValue.softDelete = true

        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}/softdelete/${formValue.itemId}`
        return this.httpClient.put<Category>(url, JSON.stringify(formValue), {
            headers: urlHeaders,
        })
    }
}
