import { Injectable } from '@angular/core'
import { SelectItem } from 'primeng/api'
import _ from 'lodash'
import { Item } from '../models/item'
import { Business } from '../models/business'
import { Category } from '@app/models/category'

@Injectable({
    providedIn: 'root',
})
export class UtilityService {
    constructor() {}

    mapItemsToSelect(items): SelectItem[] {
        return _.flatMap(items, (value, key) => {
            return {
                value: value.id,
                label: value.name,
            }
        })
    }
}
