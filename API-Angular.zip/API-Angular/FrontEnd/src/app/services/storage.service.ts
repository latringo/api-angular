import { Injectable } from '@angular/core'
import { from, BehaviorSubject, Subject, Subscription } from 'rxjs'
import * as localForage from 'localforage'
import { firstBy } from 'thenby'
import _ from 'lodash'

import { BusinessService } from './business.service'
import { CategoryService } from './category.service'
import { InventoryService } from './inventory.service'
import { ItemService } from './item.service'
import { SupplierService } from './supplier.service'

import { Business } from '../models/business'
import { Category } from '../models/category'
import { Item } from '../models/item'
import { ItemLocation } from '../models/itemlocation'
import { ShoppingList } from '../models/shoppinglist'
import { ShoppingListItem } from '../models/shoppinglistitem'
import { Supplier } from '../models/supplier'

@Injectable({
    providedIn: 'root',
})
export class StorageService {
    // private _business = new BehaviorSubject<Business[]>([]);
    // private businessStore: { business: Business[] } = { business: [] };
    // readonly business = this._business.asObservable();

    private _categories = new BehaviorSubject<Category[]>([])
    private categoryStore: { categories: Category[] } = { categories: [] }
    readonly categories = this._categories.asObservable()

    private _items = new BehaviorSubject<Item[]>([])
    private itemStore: { items: Item[] } = { items: [] }
    readonly items = this._items.asObservable()

    private _itemLocations = new BehaviorSubject<ItemLocation[]>([])
    private itemLocationStore: { itemLocations: ItemLocation[] } = {
        itemLocations: [],
    }
    readonly itemLocations = this._itemLocations.asObservable()

    private _shoppingCarts = new BehaviorSubject<ShoppingList[]>([])
    private shoppingCartStore: { shoppingCarts: ShoppingList[] } = {
        shoppingCarts: [],
    }
    readonly shoppingCarts = this._shoppingCarts.asObservable()

    private _shoppingCartItems = new BehaviorSubject<ShoppingListItem[]>([])
    private shoppingCartItemStore: { shoppingCartItems: ShoppingListItem[] } = {
        shoppingCartItems: [],
    }
    readonly shoppingCartItems = this._shoppingCartItems.asObservable()

    private _suppliers = new BehaviorSubject<Supplier[]>([])
    private supplierStore: { suppliers: Supplier[] } = { suppliers: [] }
    readonly suppliers = this._suppliers.asObservable()

    private subscription: Subscription
    currentBusiness: Business
    businessId: number
    public locationId: number
    public categoryId: number

    constructor(
        private businessService: BusinessService,
        private categoryService: CategoryService,
        private inventoryService: InventoryService,
        private itemService: ItemService,
        private supplierService: SupplierService
    ) {
        this.setDatabase()
    }

    setData() {
        // this.setCategories();
        // // this.setItems();
        // this.setItemLocations();
        // this.setSuppliers();
    }

    setDatabase() {
        localForage.config({
            name: 'SwiftVentoryData',
            storeName: 'swift_data',
        })
        // this.setBusiness();
    }

    public async getCurrentBusiness() {
        return await this.currentBusiness
    }

    public getComponentData() {
        const business = localForage.getItem('swift_business')
        const categories = this.categoryStore.categories
        const items = this.itemStore.items
        const itemLocations = this.itemLocationStore.itemLocations
        const shoppingCarts = this.shoppingCartStore.shoppingCarts
        const shoppingCartItems = this.shoppingCartItemStore.shoppingCartItems
        const suppliers = this.supplierStore.suppliers

        const payload = {
            business,
            categories,
            items,
            itemLocations,
            shoppingCarts,
            shoppingCartItems,
            suppliers,
        }

        return payload
    }

    // async setBusiness() {
    //   const that = this;
    //   await this.businessService.getBusinessByName('Hidden Paradise').subscribe(data => {
    //     this.currentBusiness = data as Business;
    //     localForage.setItem('swift_business', this.currentBusiness).then( (business) =>{
    //       that.setData();
    //     });
    //   });
    // }

    // async setCategories() {
    //   let categories = new Array<Category>();
    //   const businessId = this.currentBusiness.id;
    //   await this.categoryService.getCategories().subscribe(
    //     data => {
    //       categories = data as Category[];
    //       categories = _.filter(categories, (m: Category) => {
    //         const b = m.businessId === businessId;
    //         return b;
    //       }).sort((a, b) => (a.name > b.name) ? 1 : -1);
    //
    //       from(localForage.setItem('swift_categories', categories))
    //         .subscribe(() => {
    //           this.categoryStore.categories = categories;
    //           this._categories.next(Object.assign({}, this.categoryStore).categories);
    //         },
    //           error => console.log('Could not load categories')
    //         );
    //     }
    //   );
    // }

    /*async setItems() {
    let items = new Array<ItemDisplay>();
    const businessId = this.currentBusiness.id;
    this.subscription = await this.itemService.getItemsByBusiness(businessId);

      /!* items.sort(
        firstBy(function (v1, v2) { return v1.categoryId - v2.categoryId; })
          .thenBy('name')
      ); *!/

      from(localForage.setItem('swift_items', items))
        .subscribe(() => {
          this.itemStore.items = items;
          this._items.next(Object.assign({}, this.itemStore).items);
        },
          error => console.log('Could not load items')
        );
    });
  }*/

    // async setItemLocations() {
    //   let itemLocations = new Array<ItemLocation>();
    //   const businessId = this.currentBusiness.id;
    //   await this.inventoryService.getItemLocations(businessId).subscribe(
    //     data => {
    //       itemLocations = data as ItemLocation[];
    //       itemLocations = _.filter(itemLocations, (m: ItemLocation) => {
    //         const b = m.businessId === businessId;
    //         return b;
    //       }).sort((a, b) => (a.locationName > b.locationName) ? 1 : -1);
    //
    //       from(localForage.setItem('swift_itemLocations', itemLocations))
    //         .subscribe(() => {
    //           this.itemLocationStore.itemLocations = itemLocations;
    //           this._itemLocations.next(Object.assign({}, this.itemLocationStore).itemLocations);
    //         },
    //           error => console.log('Could not load item locations')
    //       )
    //     }
    //   );
    // }

    // async setSuppliers() {
    //   let suppliers = new Array<Supplier>();
    //   const businessId = this.currentBusiness.id;
    //   await this.supplierService.getSuppliers().subscribe(
    //     data => {
    //       suppliers = data as Supplier[];
    //       suppliers = _.filter(suppliers, function (m: Supplier) {
    //         const b = m.businessId === businessId;
    //         return b;
    //       }).sort((a, b) => a.name > b.name ? 1 : -1);
    //
    //       from(localForage.setItem('swift_suppliers', suppliers))
    //         .subscribe(() => {
    //           this.supplierStore.suppliers = suppliers;
    //           this._suppliers.next(Object.assign({}, this.supplierStore).suppliers);
    //         },
    //           error => console.log('Could not load suppliers')
    //       )
    //     }
    //   );
    // }
}
