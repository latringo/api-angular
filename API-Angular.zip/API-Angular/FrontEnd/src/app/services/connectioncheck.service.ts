import { Injectable, OnDestroy } from '@angular/core'
import { BehaviorSubject } from 'rxjs'
@Injectable({
    providedIn: 'root',
})
export class ConnectionCheckService implements OnDestroy {
    private _isConnected = new BehaviorSubject<boolean>(true)
    readonly isConnected = this._isConnected.asObservable()

    constructor() {
        this.setupService()
    }

    setupService() {
        window.addEventListener('load', () => {
            navigator.onLine
                ? this._isConnected.next(true)
                : this._isConnected.next(false)

            window.addEventListener('online', () => {
                this._isConnected.next(true)
            })

            window.addEventListener('offline', () => {
                this._isConnected.next(false)
            })
        })
    }

    ngOnDestroy(): void {}
}
