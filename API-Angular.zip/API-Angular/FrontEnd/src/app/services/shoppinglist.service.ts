import { Injectable } from '@angular/core'
import { HttpHeaders } from '@angular/common/http'
import { BehaviorSubject } from 'rxjs'
import _ from 'lodash'

import { HttpService } from '@core/http/http.service'
import { DataService } from '@app/services/data.service'
import { ConfigService } from '@app/services/config.service'
import { CommonService } from '@app/services/common.service'
import { ItemService } from '@app/services/item.service'
import { environment } from '@env/environment'

import { ShoppingList } from '@app/models/shoppinglist'
import { ShoppingListItem } from '@app/models/shoppinglistitem'
import { Item } from '@app/models/item'
import { Business } from '@app/models/business'
import { User } from '@app/models/user'

const apiUrl = environment.apiUrl
const businessName = environment.businessName

@Injectable({
    providedIn: 'root',
})
export class ShoppingListService {
    [x: string]: any

    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initialized = this._initialized.asObservable()

    shoppingListApi = apiUrl + 'shoppinglists'
    private _shoppingLists = new BehaviorSubject<ShoppingList[]>([])
    readonly shoppingLists = this._shoppingLists.asObservable()

    private _shoppingList = new BehaviorSubject<ShoppingList>(null)
    readonly shoppingList = this._shoppingList.asObservable()

    private _shoppingListCount = new BehaviorSubject<number>(0)
    readonly shoppingListCount = this._shoppingListCount.asObservable()

    shoppingListItemApi = apiUrl + 'shoppinglistitems'
    private _shoppingListItems = new BehaviorSubject<ShoppingListItem[]>([])
    readonly shoppingListItems = this._shoppingListItems.asObservable()

    business: Business
    user: User

    constructor(
        private httpService: HttpService,
        private dataService: DataService,
        private itemService: ItemService,
        private configService: ConfigService,
        private commonService: CommonService
    ) {}

    setUser() {
        return this.configService.getUser()
    }

    public getUser() {
        // this.user.subscribe((data) => {
        //     return data
        // })
    }

    setBusiness() {
        return this.httpService.get<Business>(
            this.businessApi + '/byname/' + businessName
        )
    }

    public getBusiness() {
        // this.business.subscribe((data) => {
        //     return data
        // })
    }

    // setBusiness() {
    //     // this.dataService.business.subscribe((data) => {
    //     //     if (data) {
    //     //         this.business = data
    //     //         this.getListCount()
    //     //     }
    //     // })
    // }

    // getListCount() {
    //     this.httpService
    //         .get<number>(
    //             this.shoppingListApi + '/shoppinglistcount/' + this.business.id
    //         )
    //         .subscribe((data) => {
    //             this._listCount.next(data)
    //             this.setShoppingList()
    //         })
    // }

    // setShoppingList() {
    //     // if (!this.business) {
    //     //     this.dataService.business.subscribe((data) => {
    //     //         if (data) {
    //     //             this.business = data
    //     //             this.getListCount()
    //     //         }
    //     //     })
    //     // }
    //     this.shoppingList.subscribe((data) => {
    //         if (!data) {
    //             const listDate = new Date()
    //             const currentDate = this.commonService.getDate()
    //             const cartName = 'Shopping list for: ' + currentDate
    //             this.listCount.subscribe((data) => {
    //                 let listCount = data
    //                 let shoppingList = new ShoppingList({
    //                     listCount: listCount,
    //                     listDate: listDate,
    //                     name: cartName,
    //                     businessId: this.business.id,
    //                     modifyBy: this.configService.getUser().id,
    //                     modifyDate: listDate,
    //                 })

    //                 this._shoppingList.next(shoppingList)
    //                 this.createShoppingList(shoppingList)
    //             })
    //         }
    //     })
    // }

    // public newShoppingList(): ShoppingList {
    //     let listItems: ShoppingListItem[]
    //     this.shoppingListItems.subscribe((data) => {
    //         listItems = data
    //     })
    //     const currentDate = this.commonService.getDate()
    //     const shoppingList = new ShoppingList({
    //         id: 0,
    //         listCount: this.shoppingListCount,
    //         listDate: new Date(),
    //         name: this.getCartName(),
    //         businessId: this.business.id,
    //         notes: '',
    //         listItems: listItems,
    //         modifyBy: this.configService.getUser().id,
    //         modifyDate: currentDate,
    //         softDelete: false,
    //     })
    //     return shoppingList
    //     // this.createShoppingList(shoppingList).subscribe((data) => {
    //     //     this.shoppingList = data
    //     // })
    // }

    public updateShoppingList(shoppingList: ShoppingList) {
        this._shoppingList.next(shoppingList)
    }

    updateListItems(listItem: ShoppingListItem) {
        if (listItem.item.currentOnHand <= listItem.item.minimumAmount) {
            this.shoppingListItems.subscribe((data: ShoppingListItem[]) => {
                let listItems: ShoppingListItem[]
                listItems = data
                listItems.push(listItem)
                this._shoppingListItems.next(listItems)
            })
        }
        this.sortShoppingList()
    }

    saveShoppingList(shoppingList: ShoppingList) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.apiUrl}/${shoppingList.id}`
        this.httpService
            .put<ShoppingList>(url, shoppingList, {
                headers: urlHeaders,
            })
            .subscribe((data) => {
                this._shoppingList.next(data)
            })
    }

    // createShoppingList(shoppingList: ShoppingList) {
    //     const urlHeaders = new HttpHeaders({
    //         'Content-Type': 'application/json',
    //         'Access-Control-Allow-Origin': '*',
    //     })
    //     const url = `${this.shoppingListApi}`
    //     this.httpService
    //         .post<ShoppingList>(url, shoppingList, {
    //             headers: urlHeaders,
    //         })
    //         .subscribe((data) => {
    //             let list = this._shoppingList.value
    //             list.id = data.id
    //             this._shoppingList.next(list)
    //             // this.shoppingList.subscribe((list) => {
    //             //     list.id = data.id
    //             //     this._shoppingList.next(list)
    //             // })
    //         })
    // }

    // getShoppingList() {}

    // removeFromShoppingList(item: ShoppingListItem) {
    //     this.dataService.shoppingList.subscribe((shoppingList) => {
    //         _.remove(shoppingList.listItems, (listItem: ShoppingListItem) => {
    //             return listItem.itemId === item.id
    //         })
    //         _.sortBy(shoppingList.listItems,[
    //             'item.supplierId',
    //             'item.categoryId',
    //             'item.locationId',
    //             'item.name',
    //         ])
    //     })

    //     this.sortShoppingList()
    // }

    // sortShoppingList() {
    //     this.dataService.shoppingList.subscribe((shoppingList) => {
    //         _.sortBy(shoppingList.listItems,[
    //             'item.supplierId',
    //             'item.categoryId',
    //             'item.locationId',
    //             'item.name',
    //         ])
    //         this.dataService._shoppingList.next(shoppingList)
    //     })
    // }

    // getCartName() {
    //     const date = new Date()
    //     const month = date.getUTCMonth() + 1
    //     const day = date.getUTCDate()
    //     const year = date.getUTCFullYear()
    //     const cartName =
    //         '_ShoppingList_' +
    //         month +
    //         '/' +
    //         day +
    //         '/' +
    //         year +
    //         this.shoppingCartCount
    //     return cartName
    // }

    // public updateItemAmountOnHand(item: Item) {
    //     this.observableSaving.next(true)
    //     const urlHeaders = new HttpHeaders({
    //         'Content-Type': 'application/json',
    //     })
    //     const url = `${this.apiUrl}/updateonhand/${item.id}/${item.currentOnHand}`
    //     this.http
    //         .put<Item>(url, { headers: urlHeaders })
    //         .subscribe(() => {
    //             this.shoppingListService.updateListItems(item)
    //             setTimeout(() => {
    //                 this.observableSaving.next(false)
    //             }, 1500)
    //         })
    // }
}
