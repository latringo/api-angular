import { Injectable } from '@angular/core'
import { BehaviorSubject, forkJoin, Observable, Subscription } from 'rxjs'
import _ from 'lodash'

import { environment } from '@env/environment'
import { HttpService } from '@core/http/http.service'
import { ConnectionCheckService } from '@app/services/connectioncheck.service'
import { ConfigService } from './config.service'
import { LocalStorageService } from '@app/services/localstorage.service'
import { CommonService } from '@app/services/common.service'

import { User } from '@app/models/user'
import { Business } from '@app/models/business'
import { Category } from '@app/models/category'
import { Item } from '@app/models/item'
import { ItemLocation } from '@app/models/itemlocation'
import { UnitOfMeasure } from '@app/models/unitofmeasure'
import { Supplier } from '@app/models/supplier'
import { State } from '@app/models/state'
import { HttpHeaders } from '@angular/common/http'
import { ShoppingList } from '@app/models/shoppinglist'
import { ShoppingListItem } from '@app/models/shoppinglistitem'

const apiUrl = environment.apiUrl
const businessName = environment.businessName
const adminPages = environment.adminPages

@Injectable({
    providedIn: 'root',
})
export class DataService {
    isConnected: boolean = true

    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initializedSubscribe = this._initialized.asObservable()

    private _user = new BehaviorSubject<User>(null)
    readonly user = this._user.asObservable()

    autoCompleteApi = apiUrl + 'items/getitemautocomplete'
    private _autoCompleteItems = new BehaviorSubject<Item[]>([])
    readonly autoCompleteItemsSubscribe = this._autoCompleteItems.asObservable()

    businessApi = apiUrl + 'businesses'
    private _business = new BehaviorSubject<Business>(null)
    readonly business = this._business.asObservable()

    categoryApi = apiUrl + 'categories'
    private _categories = new BehaviorSubject<Category[]>([])
    readonly categoriesSubscribe = this._categories.asObservable()
    private _adminCategories = new BehaviorSubject<Category[]>([])
    readonly adminCategoriesSubscribe = this._categories.asObservable()

    itemApi = apiUrl + 'items'
    private _items = new BehaviorSubject<Item[]>([])
    readonly itemsSubscribe = this._items.asObservable()
    private _adminItems = new BehaviorSubject<Item[]>([])
    readonly adminItemsSubscribe = this._items.asObservable()

    itemLocationApi = apiUrl + 'itemlocations'
    private _itemLocations = new BehaviorSubject<ItemLocation[]>([])
    readonly itemLocationsSubscribe = this._itemLocations.asObservable()
    private _adminItemLocations = new BehaviorSubject<ItemLocation[]>([])
    readonly adminItemLocationsSubscribe = this._itemLocations.asObservable()

    shoppingListApi = apiUrl + 'shoppinglists'
    private _shoppingLists = new BehaviorSubject<ShoppingList[]>([])
    readonly shoppingListsSubscribe = this._shoppingLists.asObservable()
    private _shoppingList = new BehaviorSubject<ShoppingList>(null)
    readonly shoppingListSubscribe = this._shoppingList.asObservable()

    private _shoppingListCount = new BehaviorSubject<number>(0)
    readonly shoppingListCountSubscribe = this._shoppingListCount.asObservable()

    shoppingListItemApi = apiUrl + 'shoppinglistitems'
    private _shoppingListItems = new BehaviorSubject<ShoppingListItem[]>([])
    readonly shoppingListItemsSubscribe = this._shoppingListItems.asObservable()

    stateApi = apiUrl + 'states'
    private _states = new BehaviorSubject<State[]>([])
    readonly states = this._states.asObservable()

    supplierApi = apiUrl + 'suppliers'
    private _suppliers = new BehaviorSubject<Supplier[]>([])
    readonly suppliersSubscribe = this._suppliers.asObservable()
    private _adminSuppliers = new BehaviorSubject<Supplier[]>([])
    readonly adminSuppliersSubscribe = this._suppliers.asObservable()

    unitOfMeasureApi = apiUrl + 'unitsofmeasure'
    private _unitsOfMeasure = new BehaviorSubject<UnitOfMeasure[]>([])
    readonly unitsOfMeasureSubscribe = this._unitsOfMeasure.asObservable()

    quickViewApi = apiUrl + 'items/getquickviews'
    private _quickViewItems = new BehaviorSubject<Item[]>([])
    readonly quickViewItemsSubscribe = this._quickViewItems.asObservable()

    public initialized: boolean = false
    private initializedSubscription: Subscription
    public categories: Category[]
    public adminCategories: Category[]
    private categoriesSubscription: Subscription
    private adminCategoriesSubscription: Subscription
    public items: Item[]
    public adminItems: Item[]
    private itemsSubscription: Subscription
    private adminItemsSubscription: Subscription
    public itemLocations: ItemLocation[]
    public adminItemLocations: ItemLocation[]
    private itemLocationSubscription: Subscription
    private adminItemLocationSubscription: Subscription
    public shoppingList: ShoppingList
    private shoppingListSubscription: Subscription
    public shoppingItems: ShoppingListItem[]
    private shoppingItemsSubscription: Subscription
    public shoppingListCount: number
    private shoppingListCountSubscription: Subscription
    public suppliers: Supplier[]
    public adminSuppliers: Supplier[]
    private suppliersSubscription: Subscription
    private adminSuppliersSubscription: Subscription
    public quickViewItems: Item[]
    private quickViewItemsSubscription: Subscription
    public unitsOfMeasure: UnitOfMeasure[]
    private unitsOfMeasureSubscription: Subscription

    public shoppingListId: number

    businessId: number
    event$: Subscription
    adminPage: boolean = false
    navPage = ''

    constructor(
        private httpService: HttpService,
        private connectionCheck: ConnectionCheckService,
        private configService: ConfigService,
        private commonService: CommonService,
        private localStorageService: LocalStorageService
    ) {
        this.connectionCheck.isConnected.subscribe((data) => {
            this.isConnected = data
        })
        this.setInitialData()
    }

    getAdminPage(): boolean {
        let inArray: number
        inArray = _.findIndex(adminPages, (page: string) => {
            return window.location.pathname.toLowerCase() === page
        })

        return inArray > -1
    }

    setInitialData() {
        this.setBusiness().subscribe((data) => {
            this._business.next(data)
            this.businessId = data.id
            this._user.next(this.setUser())
            this.setData()
        })

        this.initializedSubscription = this.initializedSubscribe.subscribe(
            (data) => {
                this.initialized = data
                if (data) {
                    if (!this.getAdminPage()) {
                        this.shoppingListSubscribe.subscribe((data) => {
                            if (!data) {
                                this.checkForCurrentShoppingList()
                            }
                        })
                    }
                }
            }
        )

        this.categoriesSubscription = this.categoriesSubscribe.subscribe(
            (categories) => {
                this.categories = categories
            }
        )

        this.adminCategoriesSubscription =
            this.adminCategoriesSubscribe.subscribe((categories) => {
                this.adminCategories = categories
            })

        this.itemLocationSubscription = this.itemLocationsSubscribe.subscribe(
            (itemLocations) => {
                this.itemLocations = itemLocations
            }
        )

        this.adminItemLocationSubscription =
            this.adminItemLocationsSubscribe.subscribe((itemLocations) => {
                this.adminItemLocations = itemLocations
            })

        this.itemsSubscription = this.itemsSubscribe.subscribe((items) => {
            this.items = items
        })

        this.adminItemsSubscription = this.adminItemsSubscribe.subscribe(
            (items) => {
                this.adminItems = items
            }
        )

        this.shoppingListCountSubscription =
            this.shoppingListCountSubscribe.subscribe((listCount) => {
                this.shoppingListCount = listCount
            })

        this.shoppingListSubscription = this.shoppingListSubscribe.subscribe(
            (shoppingList) => {
                this.shoppingList = shoppingList
            }
        )

        this.shoppingItemsSubscription =
            this.shoppingListItemsSubscribe.subscribe((listItems) => {
                this.shoppingItems = listItems
            })

        this.suppliersSubscription = this.suppliersSubscribe.subscribe(
            (suppliers) => {
                this.suppliers = suppliers
            }
        )

        this.adminSuppliersSubscription =
            this.adminSuppliersSubscribe.subscribe((suppliers) => {
                this.adminSuppliers = suppliers
            })

        this.quickViewItemsSubscription =
            this.quickViewItemsSubscribe.subscribe((items) => {
                this.quickViewItems = items
            })

        this.unitsOfMeasureSubscription =
            this.unitsOfMeasureSubscribe.subscribe((items) => {
                this.unitsOfMeasure = items
            })
    }

    ngOnDestroy() {
        this.initializedSubscription.unsubscribe()
        this.categoriesSubscription.unsubscribe()
        this.adminCategoriesSubscription.unsubscribe()
        this.itemLocationSubscription.unsubscribe()
        this.adminItemLocationSubscription.unsubscribe()
        this.itemsSubscription.unsubscribe()
        this.adminItemsSubscription.unsubscribe()
        this.shoppingListCountSubscription.unsubscribe()
        this.shoppingListSubscription.unsubscribe()
        this.shoppingItemsSubscription.unsubscribe()
        this.suppliersSubscription.unsubscribe()
        this.adminSuppliersSubscription.unsubscribe()
        this.quickViewItemsSubscription.unsubscribe()
        this.unitsOfMeasureSubscription.unsubscribe()
    }

    setData() {
        this.initializeData().subscribe((dataArray) => {
            this._categories.next(_.sortBy(dataArray[0], ['name']))
            this._adminCategories.next(_.sortBy(dataArray[1], ['name']))

            this._items.next(_.sortBy(dataArray[2], ['category', 'name']))
            this._adminItems.next(_.sortBy(dataArray[3], ['category', 'name']))

            this._autoCompleteItems.next(_.sortBy(this._items.value, ['name']))

            this._itemLocations.next(dataArray[4])
            this._adminItemLocations.next(dataArray[5])

            this._states.next(_.sortBy(dataArray[6], ['name']))

            this._suppliers.next(_.sortBy(dataArray[7], ['name']))
            this._adminSuppliers.next(_.sortBy(dataArray[8], ['name']))

            this._unitsOfMeasure.next(_.sortBy(dataArray[9], ['name']))
            this._quickViewItems.next(this.getQuickViewItems())
            this._shoppingListCount.next(dataArray[10])
            this._initialized.next(true)
        })
    }

    initializeData(): Observable<any> {
        const categoriesLoaded = this.setCategories()
        const adminCategoriesLoaded = this.setAdminCategories()
        const itemsLoaded = this.setItems()
        const adminItemsLoaded = this.setAdminItems()
        const itemLocationsLoaded = this.setItemLocations()
        const adminItemLocationsLoaded = this.setAdminItemLocations()
        const statesLoaded = this.setStates()
        const suppliersLoaded = this.setSuppliers()
        const adminSuppliersLoaded = this.setAdminSuppliers()
        const unitsOfMeasureLoaded = this.setUnitsOfMeasure()
        const shoppingListCountLoaded = this.setShoppingListCount()
        return forkJoin([
            categoriesLoaded,
            adminCategoriesLoaded,
            itemsLoaded,
            adminItemsLoaded,
            itemLocationsLoaded,
            adminItemLocationsLoaded,
            statesLoaded,
            suppliersLoaded,
            adminSuppliersLoaded,
            unitsOfMeasureLoaded,
            shoppingListCountLoaded,
        ])
    }

    setUser() {
        return this.configService.getUser()
    }

    public getUser() {
        this.user.subscribe((data) => {
            return data
        })
    }

    setBusiness() {
        return this.httpService.get<Business>(
            this.businessApi + '/byname/' + businessName
        )
    }

    public getBusiness() {
        this.business.subscribe((data) => {
            return data
        })
    }

    // Category methods
    setCategories() {
        return this.httpService.get<Category[]>(
            this.categoryApi + '/bybusiness/' + this.businessId
        )
    }

    setAdminCategories() {
        return this.httpService.get<Category[]>(
            this.categoryApi + '/adminbybusiness/' + this.businessId
        )
    }

    public getCategories() {
        return this.categories
    }

    public updateCategories() {
        this.setCategories().subscribe((data) => {
            this._categories.next(_.sortBy(data, ['name']))
        })
    }

    public updateAdminCategories() {
        this.setCategories().subscribe((data) => {
            this._adminCategories.next(_.sortBy(data, ['name']))
        })
    }

    public saveCategory(category: Category) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.categoryApi}/addcategory`
        return this.httpService.post<Category>(url, category, {
            headers: urlHeaders,
        })
    }

    public updateCategory(category: Category) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.categoryApi}/updatecategory/${category.id}`

        return this.httpService.put<Category>(url, category, {
            headers: urlHeaders,
        })
    }
    /*End Category methods*/

    /*Item methods*/
    setItems() {
        return this.httpService.get<Item[]>(
            this.itemApi + '/bybusiness/' + this.businessId
        )
    }

    setAdminItems() {
        return this.httpService.get<Item[]>(
            this.itemApi + '/adminbybusiness/' + this.businessId
        )
    }

    public getItems() {
        return this.items
    }

    public updateItems() {
        this.setItems().subscribe((data) => {
            this._items.next(_.sortBy(data, ['category', 'name']))
        })
    }

    public saveItem(item: Item) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.itemApi}/additem`
        return this.httpService.post<Item>(url, item, {
            headers: urlHeaders,
        })
    }

    public updateItem(item: Item) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.itemApi}/updateitem/${item.id}`

        return this.httpService.put<Item>(url, item, {
            headers: urlHeaders,
        })
    }
    /*End Item methods*/
    /*Item Location methods*/
    setItemLocations() {
        return this.httpService.get<ItemLocation[]>(
            this.itemLocationApi + '/bybusiness/' + this.businessId
        )
    }

    setAdminItemLocations() {
        return this.httpService.get<ItemLocation[]>(
            this.itemLocationApi + '/adminbybusiness/' + this.businessId
        )
    }

    public getItemLocations() {
        return this.itemLocations
    }

    public updateItemLocations() {
        this.setItemLocations().subscribe((data) => {
            this._itemLocations.next(_.sortBy(data, ['name']))
        })
    }

    public updateAdminItemLocations() {
        this.setAdminItemLocations().subscribe((data) => {
            this._itemLocations.next(_.sortBy(data, ['name']))
        })
    }

    public saveItemLocation(location: ItemLocation) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.itemLocationApi}/addlocation`
        return this.httpService.post<ItemLocation>(url, location, {
            headers: urlHeaders,
        })
    }

    public updateItemLocation(location: ItemLocation) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.itemLocationApi}/updatelocation/${location.id}`

        return this.httpService.put<ItemLocation>(url, location, {
            headers: urlHeaders,
        })
    }

    /*End Item Location methods*/

    setShoppingListCount() {
        return this.httpService.get<number>(
            this.shoppingListApi + '/shoppinglistcount/' + this.businessId
        )
    }

    public getShoppingListCount() {
        return this.shoppingListCount
    }

    checkForCurrentShoppingList() {
        this.checkCurrentShoppingList().subscribe((data) => {
            if (!data) {
                this.newShoppingList()
            } else {
                this._shoppingList.next(data)
                this.shoppingList = data
                this.shoppingListId = this.shoppingList.id
            }
        })
    }

    checkCurrentShoppingList() {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListApi}/getcurrentshoppinglist`
        return this.httpService.get<ShoppingList>(url, {
            headers: urlHeaders,
        })
    }

    newShoppingList() {
        const listDate = new Date().toISOString()
        const commonDate = this.commonService.getDate()
        const listName = 'Shopping list for: ' + commonDate
        let user: User
        this.user.subscribe((data) => {
            user = data
        })
        let shoppingList = new ShoppingList({
            listCount: this.shoppingListCount,
            listDate: listDate,
            completed: false,
            completedDate: listDate,
            name: listName,
            businessId: this.businessId,
            user: user,
            modifyBy: user.id,
            modifyDate: listDate,
        })

        this.createShoppingList(shoppingList).subscribe(
            (data: ShoppingList) => {
                this._shoppingList.next(data)
                this.shoppingList = data
                this.shoppingListId = this.shoppingList.id
            }
        )
    }

    private createShoppingList(shoppingList: ShoppingList) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListApi}`
        return this.httpService.post<ShoppingList>(url, shoppingList, {
            headers: urlHeaders,
        })
    }

    public completeShoppingList(shoppingList: ShoppingList) {
        shoppingList.completed = true
        shoppingList.completedDate = new Date().toISOString()
        this.saveShoppingList(shoppingList).subscribe((data) => {
            this.shoppingList = data
        })
    }

    public saveShoppingList(shoppingList: ShoppingList) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListApi}`
        return this.httpService.put<ShoppingList>(url, shoppingList, {
            headers: urlHeaders,
        })
    }

    addShoppingListItem(item: Item) {
        let listItem = this.mapItemToListItem(item)
        listItem.shoppingListId = this.shoppingListId
        this.upsertListItem(listItem)
    }

    upsertListItem(listItem: ShoppingListItem) {
        let inArray: number
        let currentItem = listItem
        inArray = _.findIndex(this.shoppingItems, (li: ShoppingListItem) => {
            return listItem.itemId === li.itemId
        })
        listItem.shoppingListId = this.shoppingListId
        if (inArray > -1 && this.shoppingItems.length > 0) {
            this.saveListItem(listItem).subscribe()
        } else {
            this.addListItem(listItem).subscribe((item: ShoppingListItem) => {
                if (item) {
                    currentItem = item
                }
            })
        }
        // this.getAdditionalListItems(currentItem)
        if (inArray === -1) {
            this.shoppingItems.push(currentItem)
        }
        this.sortShoppingListItems()
        this._shoppingListItems.next(this.shoppingItems)
    }

    addListItem(listItem: ShoppingListItem) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListItemApi}`
        return this.httpService.post<ShoppingListItem>(url, listItem, {
            headers: urlHeaders,
        })
    }

    saveListItem(listItem: ShoppingListItem) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListItemApi}/updatelistitem/${listItem.itemId}`
        return this.httpService.put<ShoppingListItem>(url, listItem)
    }

    updateItemFromShoppingList(listItem: ShoppingListItem) {
        let item = _.find(this.items, (item: Item) => {
            return item.id === listItem.itemId
        })
        if (!listItem.costPerUnit) {
            item.currentCost = 0
        } else {
            item.currentCost = listItem.costPerUnit
        }

        this.updateItem(item).subscribe()
        this.saveListItem(listItem).subscribe()
    }

    removeShoppingListItem(listItem: ShoppingListItem) {
        _.remove(this.shoppingItems, (item: ShoppingListItem) => {
            return item.itemId === listItem.itemId
        })
        this.deleteListItem(listItem).subscribe(() => {
            this.sortShoppingListItems()
        })
    }

    deleteListItem(listItem: ShoppingListItem) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListItemApi}` + '/' + listItem.id
        return this.httpService.delete<ShoppingListItem>(url, {
            headers: urlHeaders,
        })
    }

    getShoppingListItems() {
        return this.shoppingItems
    }

    saveShoppingListItem(listItem: ShoppingListItem) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.shoppingListItemApi}/${listItem.id}`
        return this.httpService.put<ShoppingListItem>(url, listItem, {
            headers: urlHeaders,
        })
    }

    public inShoppingList(item: Item) {
        let inArray: number
        inArray = _.findIndex(this.shoppingItems, (li: ShoppingListItem) => {
            return item.id === li.itemId
        })
        return inArray
    }

    public mapItemToListItem(item: Item): ShoppingListItem {
        let index = this.inShoppingList(item)
        if (index === -1) {
            let listItem = new ShoppingListItem({
                shoppingListId: this.shoppingListId,
                itemId: item.id,
                itemName: item.name,
                categoryId: item.category.id,
                categoryName: item.category.name,
                purchaseAmount: item.purchaseAmount,
                supplierId: item.supplier.id,
                supplierName: this.getSupplierName(item.supplier.id),
                unitOfMeasureId: item.unitOfMeasure.id,
                unitOfMeasureName: item.unitOfMeasure.name,
                onHand: item.currentOnHand,
                costPerUnit: item.currentCost,
            })
            return listItem
        } else {
            let listItem = _.find(
                this.shoppingItems,
                (li: ShoppingListItem) => {
                    return li.itemId === item.id
                }
            )
            return listItem
        }
    }

    public getSupplierName(id: number) {
        let supplier = _.find(this.suppliers, (supplier: Supplier) => {
            return supplier.id === id
        })
        return supplier.name
    }

    public getAdditionalListItems(listItem: ShoppingListItem) {
        let categoryName = _.find(this.categories, (category: Category) => {
            return category.id === listItem.categoryId
        })

        let supplierName = _.find(this.suppliers, (supplier: Supplier) => {
            return supplier.id === listItem.supplierId
        })

        let unitOfMeasure = _.find(
            this.unitsOfMeasure,
            (uom: UnitOfMeasure) => {
                return (uom.id = listItem.unitOfMeasureId)
            }
        )
        listItem.categoryName = categoryName
        listItem.supplierName = supplierName
        listItem.unitOfMeasureName = unitOfMeasure.name
    }

    public sortShoppingListItems() {
        this.shoppingItems = _.sortBy(this.shoppingItems, [
            'item.supplierId',
            'item.categoryId',
            'item.locationId',
            'item.name',
        ])
    }

    setStates() {
        return this.httpService.get<State>(this.stateApi)
    }

    public getStates() {
        this.states.subscribe((data) => {
            return data
        })
    }

    setSuppliers() {
        return this.httpService.get<Supplier[]>(
            this.supplierApi + '/bybusiness/' + this.businessId
        )
    }

    setAdminSuppliers() {
        return this.httpService.get<Supplier[]>(
            this.supplierApi + '/adminbybusiness/' + this.businessId
        )
    }

    public getSuppliers() {
        return this.suppliers
    }

    public updateSuppliers() {
        this.setSuppliers().subscribe((data) => {
            this._adminSuppliers.next(_.sortBy(data, ['name']))
        })
    }

    public updateAdminSuppliers() {
        this.setAdminSuppliers().subscribe((data) => {
            this._adminSuppliers.next(_.sortBy(data, ['name']))
        })
    }

    public saveSupplier(supplier: Supplier) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
        })
        const url = `${this.supplierApi}`
        return this.httpService.post<Supplier>(url, supplier, {
            headers: urlHeaders,
        })
    }

    public updateSupplier(supplier: Supplier) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.supplierApi}/supplierupdate/${supplier.id}`
        return this.httpService.put<any>(url, supplier, {
            headers: urlHeaders,
        })
    }

    /*end of supplier methods */

    setUnitsOfMeasure() {
        return this.httpService.get<UnitOfMeasure[]>(this.unitOfMeasureApi)
    }

    public getUnitsOfMeasure() {
        return this.unitsOfMeasure
    }

    public updateUnitsOfMeasure() {
        this.setUnitsOfMeasure().subscribe((data) => {
            this._unitsOfMeasure.next(_.sortBy(data, ['name']))
        })
    }

    public saveUnitOfMeasure(uom: UnitOfMeasure) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.unitOfMeasureApi}`
        return this.httpService.post<UnitOfMeasure>(url, uom, {
            headers: urlHeaders,
        })
    }

    public updateUnitOfMeasure(uom: UnitOfMeasure) {
        const urlHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        })
        const url = `${this.unitOfMeasureApi}/${uom.id}`

        return this.httpService.put<UnitOfMeasure>(url, uom, {
            headers: urlHeaders,
        })
    }

    public getQuickViewItems() {
        let quickViewList = _.filter(this.items, (item: Item) => {
            return item.quickView
        })
        return quickViewList
    }
}
