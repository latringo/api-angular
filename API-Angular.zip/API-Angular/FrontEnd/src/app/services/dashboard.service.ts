import { Injectable } from '@angular/core'
import { environment } from '@env/environment'
import { HttpClient, HttpHeaders } from '@angular/common/http'

import { Item } from '@app/models/item'

const apiUrl = environment.apiUrl
@Injectable({
    providedIn: 'root',
})
export class DashboardService {
    showSpinner = true
    itemsApiUrl: string
    businessId: number
    userId: number = environment.userId

    constructor(private httpClient: HttpClient) {
        this.itemsApiUrl = apiUrl + 'items'
    }

    // updateItemOnHand(item: Item) {
    //     const onHand = item.currentOnHand
    //     const urlHeaders = new HttpHeaders({
    //         'Content-Type': 'application/json',
    //     })
    //     const url = `${this.itemsApiUrl}/updateitemonhand/${item.id}/${onHand}`
    //     if (item.currentOnHand < item.minimumAmount) {
    //         item.warning = true
    //     }
    //     return this.httpClient.put<boolean>(url, JSON.stringify(item), {
    //         headers: urlHeaders,
    //     })
    // }
}
