import { Injectable } from '@angular/core'
import { BehaviorSubject, forkJoin, Observable, Subject } from 'rxjs'
import _ from 'lodash'
import { HttpHeaders } from '@angular/common/http'
import { HttpService } from '@core/http/http.service'

import { DataService } from '@app/services/data.service'
import { CommonService } from '@app/services/common.service'
import { ConfigService } from './config.service'

import { ShoppingList } from '@app/models/shoppinglist'
import { Item } from '@app/models/item'
import { ShoppingListItem } from '@app/models/shoppinglistitem'
import { Business } from '@app/models/business'
import { SelectItem } from 'primeng/api'
import { Category } from '@app/models/category'
import { ItemLocation } from '@app/models/itemlocation'
import { Supplier } from '@app/models/supplier'
import { UnitOfMeasure } from '@app/models/unitofmeasure'

import { User } from '@app/models/user'
import { FormGroup } from '@angular/forms'

@Injectable({
    providedIn: 'root',
})
export class ItemService {
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initialized = this._initialized.asObservable()

    items: Item[]
    shoppingList: ShoppingList
    shoppingListItems: Item[]
    categories: Category[]
    suppliers: Supplier[]
    itemLocations: ItemLocation[]
    unitsOfMeasure: UnitOfMeasure[]

    private addToCartSource = new Subject<Item>()
    addtoShoppingCartConfirmed$ = this.addToCartSource.asObservable()
    private removeFromCartSource = new Subject<Item>()
    removeFromCartSourceConfirmed$ = this.removeFromCartSource.asObservable()

    itemsInitialized: boolean = false
    shoppingListItemsInitialized: boolean = false
    categoriesInitialized: boolean = false
    suppliersInitialized: boolean = false
    itemLocationsInitialized: boolean = false
    unitsOfMeasureInitialized: boolean = false

    categoryOptions: SelectItem[] = []
    supplierOptions: SelectItem[] = []
    itemLocationOptions: SelectItem[] = []
    unitsOfMeasureOptions: SelectItem[] = []

    currentItem: Item
    currentLocation: ItemLocation
    currentCategory: Category
    currentSupplier: Supplier

    apiUrl: string
    business: Business
    public businessId: number
    isInitiated: boolean
    isConnected: boolean
    user: User
    userName: string
    modifyDate: Date
    private saving: boolean
    observableSaving
    private cartItems: Item[]
    observableCartItems

    constructor(
        private dataService: DataService,
        private httpClient: HttpService,
        private configService: ConfigService,
        private commonService: CommonService
    ) {
        this.initialize()
    }

    initialize() {
        this._initialized.next(false)
        this.initialized.subscribe((data) => {
            if (data) {
                this.modifyDate = new Date()
                this.user = this.configService.getUser()
                this.saving = false
                this.observableSaving = new BehaviorSubject<boolean>(
                    this.saving
                )
                this.cartItems = []
                this.observableCartItems = new BehaviorSubject<Item[]>(
                    this.cartItems
                )
            }
        })
        this.apiUrl = this.configService.getApiUrl() + 'items'
        this.categories = this.dataService.categories
        this.categoryOptions = this.commonService.mapItemsToSelect(
            this.categories
        )

        this.suppliers = this.dataService.suppliers
        this.supplierOptions = this.commonService.mapItemsToSelect(
            this.suppliers
        )

        this.itemLocations = this.dataService.itemLocations
        this.itemLocationOptions = this.commonService.mapItemsToSelect(
            this.itemLocations
        )

        this.unitsOfMeasure = this.dataService.unitsOfMeasure
        this.unitsOfMeasureOptions = this.commonService.mapItemsToSelect(
            this.unitsOfMeasure
        )

        this.items = this.dataService.items
    }

    checkInitialized() {
        let initialized =
            this.categoriesInitialized &&
            this.suppliersInitialized &&
            this.itemLocationsInitialized &&
            this.unitsOfMeasureInitialized &&
            this.itemsInitialized

        this._initialized.next(initialized)
    }

    // called when location and category dropdowns are activated
    public getCurrentItems() {
        _.filter(this.items, (item: Item) => {
            return (
                item.itemLocationId == this.currentLocation.id &&
                item.categoryId == this.currentCategory.id
            )
        })
    }

    public getItemsByItemLocationCategorySupplier() {
        _.filter(this.items, (item: Item) => {
            return (
                item.itemLocationId == this.currentLocation.id &&
                item.categoryId == this.currentCategory.id &&
                item.supplierId == this.currentSupplier.id
            )
        })
    }

    public getItemsByLocationCategory() {
        _.filter(this.items, (item: Item) => {
            return (
                item.itemLocationId == this.currentLocation.id &&
                item.categoryId == this.currentCategory.id
            )
        })
    }

    public getItem(id: number) {
        this.currentItem = _.find(this.items, (item: Item) => {
            return item.id === id
        })
    }

    createItem(currentItem: Item, itemForm: FormGroup) {
        // this.dataService.saveItemForm(itemForm).subscribe((data) => {
        //     this.currentItem = data
        // })
    }

    deleteItem(data: any, itemForm: FormGroup) {
        this.currentItem.softDelete = true
        this.dataService.updateItem(this.currentItem).subscribe((data) => {
            this.currentItem = new Item()
            this.dataService.setItems()
        })
    }

    mapToListItem(item: Item): ShoppingListItem {
        return this.dataService.mapItemToListItem(item)
    }

    public updateInventoryItem(item: Item) {
        this.dataService.updateItem(item).subscribe((data) => {
            this.currentItem = data
        })
    }

    public updateItem(currentItem: Item, formValue: any) {
        let item: Item = formValue

        this.dataService.updateItem(item).subscribe((data) => {
            this.currentItem = data
        })
    }

    public getCartItems(businessId: number) {
        const apiUrl = this.apiUrl + '/bybusiness/' + businessId
        return this.httpClient.get<Item[]>(apiUrl)
    }

    // todo validate this formula
    amountToBuy(item: Item) {
        let amount = item.minimumAmount - item.currentOnHand
        if (amount < 0) {
            return 0
        } else {
            if (amount < item.currentPurchasedAmount) {
                amount = item.currentPurchasedAmount
            }
            this.cartItems.push(item)
            this.observableCartItems.next(this.cartItems)
            return amount
        }
    }
}
