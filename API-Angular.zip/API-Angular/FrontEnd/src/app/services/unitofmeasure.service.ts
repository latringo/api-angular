import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { UnitOfMeasure } from '@app/models/unitofmeasure'
import { ConfigService } from '@app/services/config.service'

@Injectable({
    providedIn: 'root',
})
export class UnitOfMeasureService {
    apiUrl: string
    unitsOfMeasure: UnitOfMeasure[]

    constructor(
        private http: HttpClient,
        private configService: ConfigService
    ) {
        this.apiUrl = this.configService.getApiUrl() + 'unitsofmeasure'
        this.getUnitsOfMeasure()
    }

    getUnitsOfMeasure() {
        return this.http.get<UnitOfMeasure[]>(this.apiUrl).subscribe((data) => {
            this.unitsOfMeasure = data
        })
    }
}
