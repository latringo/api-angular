import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { ConfigService } from '../services/config.service'
import { State } from '../models/state'
import { SelectItem } from 'primeng/api'
import _ from 'lodash'

@Injectable({
    providedIn: 'root',
})
export class CommonService {
    apiUrl: string
    constructor(private httpClient: HttpClient) {}

    getStates() {
        return this.httpClient.get<State[]>(this.apiUrl)
    }

    public getDate() {
        const date = new Date()
        const year = date.getFullYear()
        const month = date.getMonth() + 1
        const day = date.getDate()
        return month + '/' + day + '/' + year
    }

    mapItemsToSelect(items): SelectItem[] {
        return _.flatMap(items, (value, key) => {
            return {
                value: value.id,
                label: value.name,
            }
        })
    }
}
