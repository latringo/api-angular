import { Injectable, Output, EventEmitter } from '@angular/core'
import { BehaviorSubject } from 'rxjs'
import { LoginModel } from '../models/login'

@Injectable({
    providedIn: 'root',
})
export class AccountService {
    isLoggedIn: boolean = false
    private isLoggedInSource = new BehaviorSubject(this.isLoggedIn)
    currentLoggedIn = this.isLoggedInSource.asObservable()

    constructor() {}

    public loginUser(loginModel: LoginModel) {
        let loggedIn = false
        if (
            loginModel.username === 'latringo@gmail.com' &&
            loginModel.password === 'password'
        ) {
            loggedIn = true
        }

        this.isLoggedInSource.next(loggedIn)
    }
}
