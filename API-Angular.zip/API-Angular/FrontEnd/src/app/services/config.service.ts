import { Inject, Injectable, Optional } from '@angular/core'
import { HttpService } from '@core/http/http.service'
import { Business } from '@app/models/business'
import { User } from '@app/models/user'
import { environment } from '@env/environment'
import { BehaviorSubject } from 'rxjs'

// App/src/environments/environment.ts
export const apiUrl = environment.apiUrl
export const businessName = environment.businessName

@Injectable({
    providedIn: 'root',
})
export class ConfigService {
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initialized = this._initialized.asObservable()

    private _business = new BehaviorSubject<Business>(null)
    readonly business = this._business.asObservable()

    apiUrl: string
    constructor(private httpService: HttpService) {
        this.initialize()
    }

    initialize() {
        this.apiUrl = this.getApiUrl()
        this._initialized.next(true)
        // this.getBusiness().subscribe((data) => {
        //     this._business.next(data)
        //     this._initialized.next(true)
        // })
    }

    setBusiness() {
        const url = this.getApiUrl() + 'businesses/byname/' + businessName
        return this.httpService.get<Business>(url)
    }

    getBusiness() {
        const url = this.getApiUrl() + 'businesses/byname/' + businessName
        return this.httpService.get<Business>(url)
    }

    getApiUrl() {
        return environment.apiUrl
        // return 'https://localhost:5002/api/';
    }

    getRpcUrl() {
        return 'https://localhost:5002/rpc/'
    }

    getUser() {
        return new User({
            id: 1,
            name: 'James',
            email: 'latringo@gmail.com',
            businessId: 6,
            modifyBy: 'james',
            modifyDate: new Date(),
            softDelete: false,
        })
    }

    // public getDate(){
    //   const date = new Date();
    //   const year = date.getFullYear();
    //   const month = date.getMonth() + 1;
    //   const day = date.getDate();
    //   return new Date(month + '/' + day + '/' + year);
    // }
}
