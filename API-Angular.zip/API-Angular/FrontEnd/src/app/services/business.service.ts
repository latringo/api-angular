import { Injectable } from '@angular/core'
import { HttpService } from '@core/http/http.service'
import { ConfigService } from '@app/services/config.service'
import { Business } from '@app/models/business'

@Injectable({
    providedIn: 'root',
})
export class BusinessService {
    apiUrl: string
    business: Business

    constructor(
        private http: HttpService,
        private configService: ConfigService
    ) {
        this.configService.business.subscribe((data) => {
            this.business = data
        })

        this.apiUrl = configService.getApiUrl() + 'businesses'
    }

    getBusinesses() {
        return this.http.get<Business[]>(this.apiUrl)
    }
}
