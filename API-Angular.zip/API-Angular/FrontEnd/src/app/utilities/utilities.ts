import {Item} from '@app/models/item'
export class Utilities {
  public formatUnitOfMeasure(item: Item): string {
    const tUom = item.unitOfMeasure.name.split('-')
    tUom[0] = tUom[0].trim()
    return tUom.toString()
    // let tPlural
    // const value = item.currentOnHand
    // if (value > 1) {
    //   tPlural = 's'
    //   tUom[0] = tUom[0].trim()
    // }
    // return tUom.toString()
  }

  public formatUnitOfMeasureAutoComplete(item: Item): string {
    const tUom = item.unitOfMeasure.name.split('-')
    let tPlural
    const value = item.currentOnHand
    if (value > 1) {
      tPlural = 's'
      tUom[0] = tUom[0].trim() + tPlural
    }
    return tUom.toString()
  }
}
