import { AccountModule } from './../account/account.module'
import { AuthCallbackComponent } from './../auth/auth-callback/auth-callback.component'
import { Routes, RouterModule } from '@angular/router'
import { InventorylistComponent } from '../components/inventorylist/inventorylist.component'
import { ItemAdminComponent } from '../components/itemadmin/itemadmin.component'
import { CategoryAdminComponent } from '../components/categoryadmin/categoryadmin.component'
import { ItemLocationAdminComponent } from '../components/itemlocationadmin/itemlocationadmin.component'
import { SupplierAdminComponent } from '../components/supplieradmin/supplieradmin.component'
import { UnitsOfMeasureComponent } from '@app/components/unitsofmeasureadmin/unitsofmeasure.component'
import { ShoppinglistComponent } from '../components/shoppinglist/shoppinglist.component'
import { UserComponent } from '../components/admin/user/user.component'
import { ItemComponent } from '../components/item/item.component'
import { DashboardComponent } from '../components/dashboard/dashboard.component'
import { ReportsComponent } from '../components/reports/reports.component'
import { Shell } from '@app/shell/shell.service'
import { HomeComponent } from '@app/landing/home/home.component'

export const routes: Routes = [
    // redirects after logging in with Identity Server
    // research which is the most performant -- whether redirecting through the auth-callback
    // via this angular route, or using static page on server,
    // such as assets/callback.html
    { path: 'auth-callback', component: AuthCallbackComponent },
    {
        path: 'account',
        loadChildren: () =>
            import('../account/account.module').then((m) => m.AccountModule),
    },

    Shell.childRoutes([
        // {
        //   path: '',
        //   loadChildren: () =>
        //     import('../landing/landing.module').then((m) => m.LandingModule),
        // },
        { path: '', component: HomeComponent },
        { path: 'inventory', component: InventorylistComponent },
        // { path: 'about', loadChildren: () => import('./about/about.module').then(m => m.AboutModule) }
        {
            data: { pageTitle: 'Dashboard' },
            path: 'dashboard',
            component: DashboardComponent,
        },
        {
            data: { pageTitle: 'Inventory List' },
            path: 'inventorylist',
            component: InventorylistComponent,
        },
        {
            data: { pageTitle: 'Shopping Lists' },
            path: 'shoppinglist',
            component: ShoppinglistComponent,
        },
        {
            data: { pageTitle: 'Item Admin' },
            path: 'itemadmin',
            component: ItemAdminComponent,
        },
        {
            data: { pageTitle: 'Category Admin' },
            path: 'categoryadmin',
            component: CategoryAdminComponent,
        },
        {
            data: { pageTitle: 'Item Location Admin' },
            path: 'itemlocationadmin',
            component: ItemLocationAdminComponent,
        },
        {
            data: { pageTitle: 'Supplier Admin' },
            path: 'supplieradmin',
            component: SupplierAdminComponent,
        },
        {
            data: { pageTitle: 'Units of Measure Admin' },
            path: 'unitofmeasureadmin',
            component: UnitsOfMeasureComponent,
        },

        {
            data: { pageTitle: 'User Admin' },
            path: 'useradmin',
            component: UserComponent,
        },
        {
            data: { pageTitle: 'Reports' },
            path: 'reports',
            component: ReportsComponent,
        },
    ]),
    // { data: { pageTitle: 'Landing' }, path: 'landing', component: LandingComponent},

    // Fallback when no prior route is matched
    { path: '**', redirectTo: '', pathMatch: 'full' },
]
