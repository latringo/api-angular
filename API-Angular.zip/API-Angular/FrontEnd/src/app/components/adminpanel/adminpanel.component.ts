import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { HeaderService } from '@app/services/header.service'

@Component({
    selector: 'app-adminpanel',
    templateUrl: './adminpanel.component.html',
    styleUrls: ['./adminpanel.component.scss'],
})
export class AdminPanelComponent implements OnInit {
    itemadmin: boolean
    categoryadmin: boolean
    itemlocationadmin: boolean
    supplieradmin: boolean
    unitofmeasureadmin: boolean

    constructor(private headerService: HeaderService, private router: Router) {}

    ngOnInit(): void {
        this.setButtons()
    }

    setButtons() {
        this.itemadmin = false
        this.categoryadmin = false
        this.itemlocationadmin = false
        this.supplieradmin = false
        this.unitofmeasureadmin = false

        let pathname = window.location.pathname.toLowerCase()

        switch (pathname) {
            case '/itemadmin':
                this.itemadmin = true
                break
            case '/categoryadmin':
                this.categoryadmin = true
                break
            case '/itemlocationadmin':
                this.itemlocationadmin = true
                break
            case '/supplieradmin':
                this.supplieradmin = true
                break
            case '/unitofmeasureadmin':
                this.unitofmeasureadmin = true
                break
        }
    }

    goPage(path) {
        this.router.navigate([path])
        this.setButtons()
    }
}
