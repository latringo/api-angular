import { Component, Inject, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogConfig,
} from '@angular/material/dialog'
import _ from 'lodash'
import { SelectItem, MessageService, PrimeNGConfig } from 'primeng/api'

import { DataService } from '@app/services/data.service'
import { ConfigService } from '@app/services/config.service'
import { CommonService } from '@app/services/common.service'
import { HeaderService } from '@app/services/header.service'

import { Supplier } from '@app/models/supplier'
import { State } from '@app/models/state'
import { Business } from '@app/models/business'
import { ModalComponent } from '@app/components/modal/modal.component'
import { FormMessage } from '@app/models/form-message'
import { User } from '@app/models/user'

@Component({
    selector: 'app-supplieradmin',
    templateUrl: './supplieradmin.component.html',
    styleUrls: ['./supplieradmin.component.scss'],
})
export class SupplierAdminComponent implements OnInit {
    itemForm: FormGroup

    suppliers: Supplier[]
    currentSupplier: Supplier
    supplierOptions: SelectItem[] = []
    selectedSupplier: SelectItem
    suppliersInitialized: boolean = false

    states: State[]
    currentState: State
    statesOptions: SelectItem[] = []
    selectedState: SelectItem
    statesInitialized: boolean = false

    businessInitialized: boolean = false
    business: Business
    user: User
    errorMessage: string
    showError = false
    messageError: any
    formMessage: [{}] = [{}] // = [{severity:'info', summary:'Info Message', detail:'system is setup'}];
    initialized: boolean
    dataReady: boolean

    constructor(
        private dataService: DataService,
        private configService: ConfigService,
        private commonService: CommonService,
        private messageService: MessageService,
        private headerService: HeaderService,
        private primengConfig: PrimeNGConfig,
        private dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: MatDialogConfig
    ) {}

    ngOnInit() {
        this.primengConfig.ripple = true
        this.headerService.setTitle('Supplier Admin')
        this.headerService.setPageDescription(
            'maintain the suppliers you use. it is helpful to enter as much information as you can'
        )
        this.dataService.adminSuppliersSubscribe.subscribe((data) => {
            if (data.length) {
                this.suppliers = data
                this.supplierOptions = this.commonService.mapItemsToSelect(
                    this.suppliers
                )
                this.currentSupplier = this.suppliers[0]
                this.selectedSupplier = this.supplierOptions[0]
                this.suppliersInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.states.subscribe((data) => {
            if (data.length) {
                this.states = data
                this.statesOptions = this.commonService.mapItemsToSelect(
                    this.states
                )
                this.currentState = this.states[0]
                this.selectedState = this.statesOptions[0]
                this.statesInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.business.subscribe((data) => {
            if (data) {
                this.business = data
                this.businessInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.user.subscribe((data) => {
            this.user = data
        })
    }

    checkInitialized() {
        this.dataReady =
            this.suppliersInitialized &&
            this.statesInitialized &&
            this.businessInitialized
        if (this.dataReady) {
            this.buildForm()
        }
    }

    buildForm() {
        this.itemForm = new FormGroup({
            id: new FormControl(this.currentSupplier.id),
            name: new FormControl(
                this.currentSupplier.name,
                Validators.required
            ),
            businessId: new FormControl(this.currentSupplier.businessId),
            contact: new FormControl(this.currentSupplier.contact),
            address: new FormControl(
                this.currentSupplier.address,
                Validators.required
            ),
            city: new FormControl(
                this.currentSupplier.city,
                Validators.required
            ),
            state: new FormControl(
                this.currentSupplier.state,
                Validators.required
            ),
            zip: new FormControl(this.currentSupplier.zip, Validators.required),
            email: new FormControl(this.currentSupplier.email),
            website: new FormControl(this.currentSupplier.website),
            visible: new FormControl(this.currentSupplier.visible),
            notes: new FormControl(this.currentSupplier.notes),
        })
    }

    addNewSupplier() {
        const supplier = new Supplier({
            address: '',
            businessId: this.business.id,
            city: '',
            id: 0,
            modifyBy: this.user.name,
            modifyDate: new Date(),
            name: 'New Supplier',
            softDelete: false,
            visible: true,
            zip: 99999,
        })
        this.dataService.saveSupplier(supplier).subscribe((data) => {
            supplier.id = data.id
            this.dataService.updateSuppliers()
            this.suppliers.push(supplier)
            this.currentSupplier = supplier
            this.supplierOptions = this.commonService.mapItemsToSelect(
                this.suppliers
            )
            this.generateSupplierMessage(data)
            this.buildForm()
        })
    }

    getSupplier(evt) {
        this.currentSupplier = _.find(this.suppliers, (supplier: Supplier) => {
            return supplier.id === evt.value.value
        })
        this.buildForm()
    }

    getDeleteSupplier(id: number): Supplier {
        let supplier = _.find(this.suppliers, (supplier: Supplier) => {
            return supplier.id === id
        })
        return supplier
    }

    showDeleteModal(itemForm: Supplier) {
        let supplier: Supplier = itemForm
        const modifyDate = this.commonService.getDate()
        let supplierName = supplier.name
        let supplierId = supplier.id

        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            autoFocus: true,
            hasBackdrop: true,
            panelClass: 'app-modal',
            data: {
                apiUrl: this.dataService.supplierApi,
                modifyDate,
                modifyBy: this.user.name,
                dialogMessage:
                    'Are you sure you want to delete ' + supplier.name + '?',
                warningMessage: 'This cannot be undone.',
                headerMessage: 'Item Deletion Confirmation',
                supplierId,
                supplierName,
            },
        })

        dialogRef.afterClosed().subscribe((result) => {
            if (result && result.event === 'delete') {
                let supplier = this.getDeleteSupplier(result.data.supplierId)
                supplier.softDelete = true
                this.dataService.updateSupplier(supplier).subscribe((data) => {
                    const deletedSupplier = data
                    _.remove(this.suppliers, (supplier: Supplier) => {
                        return supplier.id === deletedSupplier.id
                    })
                    this.supplierOptions = this.commonService.mapItemsToSelect(
                        this.suppliers
                    )
                    this.dataService.updateAdminSuppliers()
                    this.buildForm()
                    this.generateSupplierMessage(data)
                })
            }
        })
    }

    generateSupplierMessage(data: any) {
        let severity = 'success'
        if (data.status === 2) {
            severity = 'error'
        }
        let message = {
            severity: severity,
            summary: data.message,
            detail: '',
        }
        this.showMessage(message)
    }

    showMessage(data: FormMessage) {
        this.messageService.add(data)
        window.setTimeout(() => {
            this.messageService.clear()
        }, 3000)
    }

    saveForm(itemForm: FormGroup) {
        let supplier: Supplier = itemForm.value
        supplier.modifyDate = new Date()
        supplier.modifyBy = this.user.name
        // let zip = supplier.zip
        // supplier.zip = zip.trim()
        if (supplier.id > 0 || supplier.id) {
            this.dataService.updateSupplier(supplier).subscribe((data) => {
                this.currentSupplier = supplier
                this.dataService.updateAdminSuppliers()
                this.generateSupplierMessage(data)
            })
        } else {
            this.dataService.saveSupplier(supplier).subscribe((data) => {
                this.currentSupplier = data
                this.dataService.updateAdminSuppliers()
                this.generateSupplierMessage(data)
            })
        }
    }
}
