import { Component, OnInit, Input } from '@angular/core'

import { ItemService } from '@app/services/item.service'
import { ModalService } from '@app/services/modal.service'
import { CategoryService } from '@app/services/category.service'
import { SupplierService } from '@app/services/supplier.service'
import { BusinessService } from '@app/services/business.service'

import { Business } from '@app/models/business'
import { Category } from '@app/models/category'
import { ItemLocation } from '@app/models/itemlocation'
import { Item } from '@app/models/item'
import { Supplier } from '@app/models/supplier'

@Component({
    selector: 'app-item',
    templateUrl: './item.component.html',
    styleUrls: ['./item.component.scss'],
})
export class ItemComponent implements OnInit {
    @Input() model: Item
    @Input() itemLocations: ItemLocation[]
    @Input() itemLocation: ItemLocation
    @Input() categories: Category[]
    @Input() category: Category
    @Input() locationId: number
    @Input() business: Business

    currentItems: Item[]
    itemToDelete: Item
    suppliers: Supplier[]
    currentSupplier: Supplier
    showModal: boolean
    businessId: number

    constructor(
        private itemService: ItemService,
        private categoryService: CategoryService,
        private modalService: ModalService,
        private supplierService: SupplierService,
        private businessService: BusinessService
    ) {}

    ngOnInit() {
        // this.businessService.businessId.subscribe(
        //   data => {
        //     this.businessId = data;
        //   }
        // );

        this.suppliers = this.supplierService.suppliers

        // this.modalService.setModalState(false);
        // this.modalService.currentModalState.subscribe(state => this.showModal = state);
    }

    onSubmit(form) {
        // this.itemService.saveItem(form);
    }

    setCategory(category: Category) {
        this.category = category
    }

    setLocation(location: ItemLocation) {
        this.itemLocation = location
    }

    setSupplier(supplier: Supplier) {
        this.currentSupplier = supplier
        const length = 8
        const tempText = this.trimLongText(this.currentSupplier.name, length)
        if (tempText.length >= length) {
            this.currentSupplier.name = tempText
        }
    }

    trimLongText(text: string, length: number) {
        let tempText = ''
        if (text.length > length) {
            tempText = text.substring(0, length - 3) + '...'
        }
        return tempText
    }

    getSupplier(supplierId: number): string {
        // let supplier = this.supplierService.getSupplier(supplierId);
        // eturn supplier.name;
        return ''
    }

    setModal(state: boolean) {
        // this.modalService.setModalState(state);
    }

    newItem() {
        const item = this.model
        item.name = 'New Item'
        return item
    }

    deleteItem(item: Item) {
        this.itemToDelete = item
        this.setModal(true)
    }

    confirmDelete(itemToDelete: Item) {
        /*    this.itemService.deleteItem(itemToDelete);
    const newItem = this.newItem();
    this.model = newItem;
    this.setModal(false);*/
    }
}
