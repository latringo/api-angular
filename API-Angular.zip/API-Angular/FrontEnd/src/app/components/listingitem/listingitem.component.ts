import { Component, OnInit, Input, OnDestroy } from '@angular/core'
import { Subscription } from 'rxjs'

import { SupplierService } from '@app/services/supplier.service'
import { ItemService } from '@app/services/item.service'
import { BusinessService } from '@app/services/business.service'

import { Item } from '@app/models/item'
import { Supplier } from '@app/models/supplier'

@Component({
    selector: 'app-listingitem',
    templateUrl: './listingitem.component.html',
    styleUrls: ['./listingitem.component.scss'],
})
export class ListingitemComponent implements OnInit {
    @Input() item: Item
    supplierList: Supplier[] = []
    subscription: Subscription
    businessId: number

    constructor(
        private supplierService: SupplierService,
        private itemService: ItemService,
        private businessService: BusinessService
    ) {}

    ngOnInit(): void {}

    getSupplier(item: Item) {
        /*this.supplierService.getSupplier(item.supplierId).subscribe(
      data => {
        return data.name;
      }
    );*/
    }

    removeItemFromShoppingList(item: Item) {
        // this.itemService.removeItemFromShoppingList(item);
    }
}
