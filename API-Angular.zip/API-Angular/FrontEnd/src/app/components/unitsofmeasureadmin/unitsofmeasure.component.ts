import { Component, Inject, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogConfig,
} from '@angular/material/dialog'
import _ from 'lodash'
import { SelectItem, MessageService, PrimeNGConfig } from 'primeng/api'

import { DataService } from '@app/services/data.service'
import { ConfigService } from '@app/services/config.service'
import { CommonService } from '@app/services/common.service'
import { HeaderService } from '@app/services/header.service'
import { ModalComponent } from '@app/components/modal/modal.component'
import { FormMessage } from '@app/models/form-message'
import { UnitOfMeasure } from '@app/models/unitofmeasure'
import { User } from '@app/models/user'
@Component({
    selector: 'app-unitsofmeasure',
    templateUrl: './unitsofmeasure.component.html',
    styleUrls: ['./unitsofmeasure.component.scss'],
})
export class UnitsOfMeasureComponent implements OnInit {
    itemForm: FormGroup
    unitsOfMeasure: UnitOfMeasure[]
    currentUnitOfMeasure: UnitOfMeasure
    unitOfMeasureOptions: SelectItem[] = []
    selectedUnitOfMeasure: SelectItem
    uomInitialized: boolean = false

    user: User
    errorMessage: string
    showError = false
    messageError: any
    formMessage: [{}] = [{}] // = [{severity:'info', summary:'Info Message', detail:'system is setup'}];
    initialized: boolean
    dataReady: boolean

    constructor(
        private dataService: DataService,
        private commonService: CommonService,
        private messageService: MessageService,
        private headerService: HeaderService,
        private primengConfig: PrimeNGConfig,
        private dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: MatDialogConfig
    ) {}

    ngOnInit(): void {
        this.primengConfig.ripple = true
        this.headerService.setTitle('Units of Measure Admin')
        this.headerService.setPageDescription(
            'maintain the units of measure used, to help make food items easier to find'
        )

        this.dataService.unitsOfMeasureSubscribe.subscribe((data) => {
            if (data.length) {
                this.unitsOfMeasure = data
                this.unitOfMeasureOptions =
                    this.commonService.mapItemsToSelect(data)

                this.currentUnitOfMeasure = this.unitsOfMeasure[0]
                this.selectedUnitOfMeasure = this.unitOfMeasureOptions[0]
                this.uomInitialized = true
                this.dataReady = true
                this.buildForm()
            }
        })

        this.dataService.user.subscribe((data) => {
            this.user = data
        })
    }

    buildForm() {
        this.itemForm = new FormGroup({
            id: new FormControl(this.currentUnitOfMeasure.id),
            name: new FormControl(
                this.currentUnitOfMeasure.name,
                Validators.required
            ),
            visible: new FormControl(this.currentUnitOfMeasure.visible),
        })
    }

    getItem(evt) {
        this.currentUnitOfMeasure = _.find(
            this.unitsOfMeasure,
            (uom: UnitOfMeasure) => {
                return uom.id === evt.value.value
            }
        )
        this.buildForm()
    }

    getDeleteUOM(id: number): UnitOfMeasure {
        let uom = _.find(this.unitsOfMeasure, (uom: UnitOfMeasure) => {
            return uom.id === id
        })
        return uom
    }

    showDeleteModal(itemForm: UnitOfMeasure) {
        let uom: UnitOfMeasure = itemForm
        const modifyDate = this.commonService.getDate()
        const uomName = uom.name
        const uomId = uom.id
        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            autoFocus: true,
            hasBackdrop: true,
            panelClass: 'app-modal',
            data: {
                apiUrl: this.dataService.itemApi,
                modifyDate,
                modifyBy: this.user.name,
                dialogMessage:
                    'Are you sure you want to delete ' + uom.name + '?',
                warningMessage: 'This cannot be undone.',
                headerMessage: 'Category Deletion Confirmation',
                uomId,
                uomName,
            },
        })

        dialogRef.afterClosed().subscribe((result) => {
            if (result && result.event === 'delete') {
                let uom = this.getDeleteUOM(result.data.uomId)
                uom.softDelete = true
                this.dataService.updateUnitOfMeasure(uom).subscribe((data) => {
                    const deletedUOM = data
                    _.remove(this.unitsOfMeasure, (uom: UnitOfMeasure) => {
                        return uom.id === deletedUOM.id
                    })
                    this.unitOfMeasureOptions =
                        this.commonService.mapItemsToSelect(this.unitsOfMeasure)
                    this.dataService.updateUnitsOfMeasure()
                    this.buildForm()
                    this.generateItemMessage(data)
                })
            }
        })
    }

    generateItemMessage(data: any) {
        let severity = 'success'
        if (data.status === 2) {
            severity = 'error'
        }
        let message = {
            severity: severity,
            summary: data.message,
            detail: '',
        }
        this.showMessage(message)
    }

    showMessage(data: FormMessage) {
        this.messageService.add(data)
        window.setTimeout(() => {
            this.messageService.clear()
        }, 3000)
    }

    addNewItem() {
        let uom = new UnitOfMeasure({
            id: 0,
            name: 'New Unit of Measure',
            visible: true,
        })
        this.dataService.saveUnitOfMeasure(uom).subscribe((data) => {
            uom.id = data.id
            this.dataService.updateUnitsOfMeasure()
            this.currentUnitOfMeasure = data
            this.generateItemMessage(data)
            this.buildForm()
        })
    }

    saveForm(itemForm: FormGroup) {
        let uom: UnitOfMeasure = itemForm.value
        if (uom.id > 0 || uom.id) {
            this.dataService.updateUnitOfMeasure(uom).subscribe((data) => {
                this.currentUnitOfMeasure = uom
                this.dataService.updateUnitsOfMeasure()
                this.generateItemMessage(data)
            })
        } else {
            this.dataService.saveUnitOfMeasure(uom).subscribe((data) => {
                this.currentUnitOfMeasure = data
                this.dataService.updateCategories()
                this.generateItemMessage(data)
            })
        }
    }
}
