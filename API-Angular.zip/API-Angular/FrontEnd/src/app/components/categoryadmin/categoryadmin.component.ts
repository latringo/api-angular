import { Component, Inject, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogConfig,
} from '@angular/material/dialog'
import _ from 'lodash'
import { SelectItem, MessageService, PrimeNGConfig } from 'primeng/api'

import { DataService } from '@app/services/data.service'
import { ConfigService } from '@app/services/config.service'
import { CommonService } from '@app/services/common.service'
import { HeaderService } from '@app/services/header.service'
import { Business } from '@app/models/business'
import { Category } from '@app/models/category'
import { ModalComponent } from '@app/components/modal/modal.component'
import { FormMessage } from '@app/models/form-message'
import { User } from '@app/models/user'
import { Item } from '@app/models/item'

@Component({
    selector: 'app-categoryadmin',
    templateUrl: './categoryadmin.component.html',
    styleUrls: ['./categoryadmin.component.scss'],
})
export class CategoryAdminComponent implements OnInit {
    itemForm: FormGroup

    categories: Category[]
    currentCategory: Category
    categoryOptions: SelectItem[] = []
    selectedCategory: SelectItem
    categoriesInitialized: boolean = false

    business: Business
    user: User
    errorMessage: string
    showError = false
    messageError: any
    formMessage: [{}] = [{}] // = [{severity:'info', summary:'Info Message', detail:'system is setup'}];
    initialized: boolean
    dataReady: boolean

    constructor(
        private dataService: DataService,
        private configService: ConfigService,
        private commonService: CommonService,
        private messageService: MessageService,
        private headerService: HeaderService,
        private primengConfig: PrimeNGConfig,
        private dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: MatDialogConfig
    ) {}

    ngOnInit() {
        this.primengConfig.ripple = true
        this.headerService.setTitle('Category Admin')
        this.headerService.setPageDescription(
            'maintain categories to manage restaurant items'
        )

        this.dataService.adminCategoriesSubscribe.subscribe((data) => {
            if (data.length) {
                this.categories = data
                this.categoryOptions = this.commonService.mapItemsToSelect(
                    this.categories
                )
                this.currentCategory = this.categories[0]
                this.selectedCategory = this.categoryOptions[0]
                this.categoriesInitialized = true
                this.dataReady = true
                this.buildForm()
            }
        })

        this.dataService.setBusiness().subscribe((data) => {
            this.business = data
        })

        this.dataService.user.subscribe((data) => {
            this.user = data
        })
    }

    buildForm() {
        this.itemForm = new FormGroup({
            name: new FormControl(
                this.currentCategory.name,
                Validators.required
            ),
            visible: new FormControl(this.currentCategory.visible),
            description: new FormControl(this.currentCategory.notes),
            id: new FormControl(this.currentCategory.id),
            businessId: new FormControl(this.currentCategory.businessId),
        })
    }

    getCategory(evt) {
        this.currentCategory = _.find(this.categories, (o: Item) => {
            return o.id === evt.value.value
        })
        this.buildForm()
    }

    getDeleteCategory(id: number): Category {
        let category = _.find(this.categories, (category: Category) => {
            return category.id === id
        })
        return category
    }

    showDeleteModal(itemForm: Category) {
        let category: Category = itemForm
        const modifyDate = this.commonService.getDate()
        const categoryName = category.name
        const categoryId = category.id
        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            autoFocus: true,
            hasBackdrop: true,
            panelClass: 'app-modal',
            data: {
                apiUrl: this.configService.getApiUrl() + 'items',
                modifyDate,
                modifyBy: this.configService.getUser(),
                dialogMessage:
                    'Are you sure you want to delete ' + category.name + '?',
                warningMessage: 'This cannot be undone.',
                headerMessage: 'Category Deletion Confirmation',
                categoryId,
                categoryName,
            },
        })

        dialogRef.afterClosed().subscribe((result) => {
            if (result && result.event === 'delete') {
                // const itemId = result.data.id;
                let category = this.getDeleteCategory(result.data.categoryId)
                category.softDelete = true
                this.dataService.updateCategory(category).subscribe((data) => {
                    const deletedCategory = data
                    _.remove(this.categories, (category: Category) => {
                        return category.id === deletedCategory.id
                    })
                    this.categoryOptions = this.commonService.mapItemsToSelect(
                        this.categories
                    )
                    this.dataService.updateCategories()
                    this.buildForm()
                    this.generateItemMessage(data)
                })
            }
        })
    }

    generateItemMessage(data: any) {
        let severity = 'success'
        if (data.status === 2) {
            severity = 'error'
        }
        let message = {
            severity: severity,
            summary: data.message,
            detail: '',
        }
        this.showMessage(message)
    }

    showMessage(data: FormMessage) {
        this.messageService.add(data)
        window.setTimeout(() => {
            this.messageService.clear()
        }, 3000)
    }

    addNewCategory() {
        let category = new Category({
            id: 0,
            name: 'New Category',
            businessId: this.business.id,
            notes: '',
            visible: true,
            softDelete: false,
            modifyBy: this.user.name,
            modifyDate: new Date(),
        })
        this.dataService.saveCategory(category).subscribe((data) => {
            category.id = data.id
            this.dataService.updateCategories()
            this.currentCategory = category
            this.generateItemMessage(data)
            this.buildForm()
        })
    }

    saveForm(itemForm: FormGroup) {
        let category: Category = itemForm.value
        category.modifyDate = new Date()
        category.modifyBy = this.user.name
        if (category.id > 0 || category.id) {
            this.dataService.updateCategory(category).subscribe((data) => {
                this.currentCategory = category
                this.dataService.updateCategories()
                this.generateItemMessage(data)
            })
        } else {
            this.dataService.saveCategory(category).subscribe((data) => {
                this.currentCategory = data
                this.dataService.updateCategories()
                this.generateItemMessage(data)
            })
        }
    }
}
