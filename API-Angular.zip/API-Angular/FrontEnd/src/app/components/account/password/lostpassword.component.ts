import { Component, OnInit } from '@angular/core'

@Component({
    selector: 'app-lostpassword',
    templateUrl: './lostpassword.component.html',
    styleUrls: ['./lostpassword.component.scss'],
})
export class LostpasswordComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
