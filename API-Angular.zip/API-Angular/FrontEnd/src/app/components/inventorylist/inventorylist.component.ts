import { Component, Input, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { BehaviorSubject } from 'rxjs'
import _ from 'lodash'

import { CommonService } from '@app/services/common.service'
import { DataService } from '@app/services/data.service'
import { HeaderService } from '@app/services/header.service'
import { Utilities } from '@app/utilities/utilities'

import { ShoppingList } from '@app/models/shoppinglist'
import { Category } from '@app/models/category'
import { Item } from '@app/models/item'
import { ItemLocation } from '@app/models/itemlocation'
import { ShoppingListItem } from '@app/models/shoppinglistitem'

import { FormGroup } from '@angular/forms'
import { SelectItem } from 'primeng/api'

@Component({
    selector: 'app-inventorylist',
    templateUrl: './inventorylist.component.html',
    styleUrls: ['./inventorylist.component.scss'],
})
export class InventorylistComponent implements OnInit {
    apiUrl: string
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initializedSubscribe = this._initialized.asObservable()

    itemLocations: ItemLocation[]
    itemLocationOptions: SelectItem[] = []
    currentItemLocation: SelectItem

    categories: Category[]
    categoryOptions: SelectItem[] = []
    currentCategory: SelectItem

    items: Item[]
    currentItem: Item

    public inventoryItems: Item[] = []
    public inventoryList: Item[] = []

    loading: boolean = true
    initialized: boolean = false
    shoppingList: ShoppingList
    listItemsCount: number = 0
    shoppingListItems: ShoppingListItem[] = []
    categoriesInitialized: boolean = false
    locationsInitialized: boolean = false
    itemsInitialized: boolean = false
    shoppingListInitialized: boolean = false
    saving: boolean = false
    itemForm: FormGroup

    @Input() item: Item

    constructor(
        private dataService: DataService,
        private router: Router,
        private headerService: HeaderService,
        private commonService: CommonService,
        private utilities: Utilities
    ) {}

    ngOnInit() {
        this.dataService.initializedSubscribe.subscribe((data) => {
            if (data) {
                this.initialize()
            }
        })

        this.dataService.shoppingListItemsSubscribe.subscribe((listItems) => {
            this.shoppingListItems = listItems
            this.listItemsCount = this.shoppingListItems.length + 1
        })
    }

    public initialize() {
        this.categoryOptions = this.commonService.mapItemsToSelect(
            this.dataService.categories
        )
        this.currentCategory = this.categoryOptions[0]

        this.itemLocationOptions = this.commonService.mapItemsToSelect(
            this.dataService.itemLocations
        )
        this.currentItemLocation = this.itemLocationOptions[0]

        this.items = this.dataService.items
        this.setInventoryItems()

        this.headerService.setTitle('Inventory List')
        this.headerService.setPageDescription(
            'Enter the amount on hand for each item on the list'
        )
        this.initialized = true
        this.loading = false
    }

    setInventoryItems() {
        this.inventoryItems = _.filter(this.items, (item: Item) => {
            return (
                item.itemLocationId === this.currentItemLocation.value &&
                item.categoryId === this.currentCategory.value
            )
        })
        _.sortBy(this.inventoryItems, ['category.name', 'name'])
    }

    formatUom(item: Item) {
        if (!item.unitOfMeasure) {
            return ''
        }
        return this.utilities.formatUnitOfMeasure(item)
    }

    updateItem(item: Item) {
        this.dataService.updateItem(item).subscribe((data) => {
            if (item.currentOnHand < item.minimumAmount) {
                let listItem = this.dataService.mapItemToListItem(item)
                this.dataService.upsertListItem(listItem)
            }
        })
    }

    goToShoppingList(path) {
        this.router.navigate([path])
    }
}
