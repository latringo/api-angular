import { Component, OnInit, Input, OnDestroy } from '@angular/core'
import { Subscription } from 'rxjs'

import { InventoryService } from '../../services/inventory.service'
// import { Item, ItemService } from '../../services/item.service';
import { ItemService } from '../../services/item.service'
import { Item } from '../../models/item'
@Component({
    selector: 'app-inventorylistitem',
    templateUrl: './inventorylistitem.component.html',
    styleUrls: ['./inventorylistitem.component.scss'],
})
export class InventoryListItemComponent implements OnInit {
    @Input() item: Item
    currentItems: Item[]
    subscription: Subscription
    addedToShoppingList = false

    constructor(
        private inventoryService: InventoryService,
        private itemService: ItemService
    ) {
        this.subscription =
            this.itemService.addtoShoppingCartConfirmed$.subscribe((data) => {
                this.addedToShoppingList = true
            })
    }

    ngOnInit() {
        // this.itemService.items.subscribe(data => {
        //   this.currentItems = data
        // });
    }

    /*  ngOnDestroy() {
    this.subscription.unsubscribe();
  }*/

    updateOnHand(item: Item, event) {
        // let id = item.id;
        // let onHand = event.target.value;
        // let status = this.itemService.updateOnHand(id, onHand);
    }

    addItemToShoppingList(item: Item) {
        // this.itemService.addItemToShoppingList(item);
    }

    removeItemFromShoppingList(item: Item) {
        // this.itemService.removeItemFromShoppingList(item);
    }

    getSupplier(supplierId: number): string {
        // let supplier = this.supplierService.getSupplier(supplierId);
        // return supplier.name;
        return ''
    }

    // getPurchaseAmount(item: Item) {
    //     let purchaseAmount = item.minimumPurchaseAmount - item.currentOnHand
    //     if (purchaseAmount < 0) {
    //         purchaseAmount = 0
    //     }
    //     return purchaseAmount
    // }
}
