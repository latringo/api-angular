import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core'
import { Route, Router, NavigationEnd, ActivatedRoute } from '@angular/router'
import { AuthenticationService } from '@app/auth'
import { HeaderService } from '@app/services/header.service'
import { filter } from 'rxjs/operators'

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
    @Output() settingsShown = new EventEmitter<boolean>()
    showmenu: boolean
    showsettings: boolean
    dashboardShown = false
    currentPage: string
    currentDescription: string

    constructor(
        public headerService: HeaderService,
        private router: Router,
        private route: ActivatedRoute,
        public authService: AuthenticationService
    ) {}

    ngOnInit() {
        this.routeEvent(this.router)
        this.showmenu = false
        this.settingsShown.emit(true)
        this.headerService.currentTitle.subscribe((data) => {
            this.currentPage = data
        })
        this.headerService.currentPageDescription.subscribe((data) => {
            this.currentDescription = data
        })
    }

    takeInventory() {
        this.router.navigate(['inventorylist'])
    }

    login() {
        this.authService.triggerSignIn()
    }

    logout() {
        this.authService.triggerSignOut()
    }

    onMenuShown(menuState: boolean) {
        this.showmenu = menuState
    }

    public setPageName(pagename: string) {
        this.currentPage = pagename
    }

    goDashboard() {
        this.router.navigate(['dashboard'])
    }

    routeEvent(router: Router) {
        router.events.subscribe((e) => {
            if (e instanceof NavigationEnd) {
                // this.dashboardShown = e.url !== '/dashboard';
                this.currentPage =
                    this.route.snapshot.firstChild.data['pageTitle']
            }
        })
    }
}
