import { Component, Input, OnInit } from '@angular/core'

import { DataService } from '@app/services/data.service'
import { ItemService } from '@app/services/item.service'
import { Subject } from 'rxjs'
import { Item } from '@app/models/item'
import { ShoppingListItem } from '@app/models/shoppinglistitem'

@Component({
    selector: 'app-inventoryitem',
    templateUrl: './inventoryitem.component.html',
    styleUrls: ['./inventoryitem.component.scss'],
})
export class InventoryItemComponent implements OnInit {
    @Input() item: Item
    itemSubject: Subject<Item> = new Subject<Item>()
    itemUpdated: boolean
    shoppingListItems: ShoppingListItem[]
    shoppingListItem: ShoppingListItem

    constructor(
        private dataService: DataService,
        private itemService: ItemService
    ) {
        // this.itemService.shoppingListItems.subscribe()
    }

    ngOnInit(): void {
        // this.itemUpdated = false
    }

    updateItem(item: Item) {
        this.dataService.updateItem(item).subscribe((data) => {
            this.dataService.setItems()
        })
    }

    amountToBuy(item: Item) {
        const amountToBuy = this.itemService.amountToBuy(item)
        item.currentPurchasedAmount = amountToBuy
        return amountToBuy
    }
}
