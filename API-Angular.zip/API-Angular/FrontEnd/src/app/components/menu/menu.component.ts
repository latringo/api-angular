import {
    Component,
    OnInit,
    EventEmitter,
    Input,
    Output,
    NgModule,
} from '@angular/core'
import { Route, Router, NavigationEnd } from '@angular/router'
import { routes } from '../../data/routes'
import { AuthenticationService } from '@app/auth'

@Component({
    selector: 'app-menu',
    templateUrl: './menu.component.html',
    styleUrls: ['./menu.component.scss'],
})
export class MenuComponent implements OnInit {
    @Input() showmenu: boolean
    @Output() menuShown = new EventEmitter<boolean>()
    routes: Route[]

    constructor(
        private router: Router // private authenticationService: AuthenticationService
    ) {
        this.routeEvent(this.router)
    }

    ngOnInit(): void {
        // todo: should test this and ensure this is a reliable way of returning all routes,
        // including those in shell and not in shell
        this.routes = routes.filter((m) => m.data)

        this.routes = this.routes[0]?.children
    }

    login() {
        console.log('logging in')
        // this.authenticationService.login();
    }

    routeEvent(router: Router) {
        router.events.subscribe((e) => {
            if (e instanceof NavigationEnd) {
                this.menuShown.emit(false)
                this.showmenu = false
            }
        })
    }
}
