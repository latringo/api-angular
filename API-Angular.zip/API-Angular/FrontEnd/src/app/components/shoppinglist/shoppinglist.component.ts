import { Component, OnInit } from '@angular/core'
import { DataService } from '@app/services/data.service'
import { CommonService } from '@app/services/common.service'
import { HeaderService } from '@app/services/header.service'
import _ from 'lodash'

import { ShoppingList } from '@app/models/shoppinglist'
import { ShoppingListItem } from '@app/models/shoppinglistitem'
import { Supplier } from '@app/models/supplier'
import { SelectItem } from 'primeng/api'
@Component({
    selector: 'app-shoppinglist',
    templateUrl: './shoppinglist.component.html',
    styleUrls: ['./shoppinglist.component.scss'],
})
export class ShoppinglistComponent implements OnInit {
    shoppingList: ShoppingList
    shoppingListItems: ShoppingListItem[] = []
    supplierListItems: ShoppingListItem[] = []
    suppliers: Supplier[]
    supplierOptions: SelectItem[] = []
    currentSupplier: SelectItem
    itemCount: number
    purchasedAmountComplete: boolean = false
    costPerUnitComplete: boolean = false

    constructor(
        private dataService: DataService,
        private headerService: HeaderService,
        private commonService: CommonService
    ) {}

    ngOnInit() {
        this.headerService.setTitle('Shopping List')
        this.headerService.setPageDescription(
            'This is a list of what to purchase by supplier'
        )
        this.dataService.shoppingListSubscribe.subscribe((shoppingList) => {
            this.shoppingList = shoppingList
        })

        this.dataService.shoppingListItemsSubscribe.subscribe((listItems) => {
            this.shoppingListItems = listItems
            this.itemCount = this.shoppingListItems.length
            this.checkItemsAndSuppliers()
        })

        this.dataService.suppliersSubscribe.subscribe((data) => {
            if (data.length) {
                this.suppliers = data
                this.supplierOptions = this.commonService.mapItemsToSelect(
                    _.sortBy(this.suppliers, ['id'])
                )
                this.currentSupplier = this.supplierOptions[0]
            }
            this.checkItemsAndSuppliers()
        })
    }

    checkItemsAndSuppliers() {
        let pathname = window.location.pathname
        if (
            pathname === '/shoppinglist' &&
            this.shoppingListItems.length > 0 &&
            this.currentSupplier
        ) {
            this.getCurrentItems()
        }
    }

    saveShoppingCart(shoppingList: ShoppingList) {
        this.dataService.completeShoppingList(shoppingList)
    }

    removeItemFromShoppingList(listItem: ShoppingListItem) {
        this.dataService.removeShoppingListItem(listItem)
        this.shoppingListItems = this.dataService.shoppingItems
        this.getCurrentItems()
    }

    updatePurchasedAmount(listItem: ShoppingListItem) {
        this.purchasedAmountComplete = true
        this.completeItem(listItem)
    }

    updateCostPerUnit(listItem: ShoppingListItem) {
        this.costPerUnitComplete = true
        this.completeItem(listItem)
    }

    completeItem(listItem: ShoppingListItem) {
        listItem.completed =
            this.purchasedAmountComplete && this.costPerUnitComplete
        if (listItem.completed) {
            this.itemCount = this.itemCount - 1
            this.updateItem(listItem)
        }
    }

    updateItem(listItem: ShoppingListItem) {
        this.dataService.updateItemFromShoppingList(listItem)
        this.purchasedAmountComplete = false
        this.costPerUnitComplete = false
    }

    updateShoppingList(shoppingList: ShoppingList) {
        this.dataService.saveShoppingList(shoppingList).subscribe()
    }

    getCurrentItems() {
        let list = _.filter(
            this.shoppingListItems,
            (item: ShoppingListItem) => {
                return item.supplierId === this.currentSupplier.value
            }
        )
        this.supplierListItems = list
    }
}
