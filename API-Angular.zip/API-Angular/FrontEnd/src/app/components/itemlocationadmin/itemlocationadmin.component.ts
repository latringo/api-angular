import { Component, Inject, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogConfig,
} from '@angular/material/dialog'
import _ from 'lodash'
import { SelectItem, MessageService, PrimeNGConfig } from 'primeng/api'

import { DataService } from '@app/services/data.service'
import { ConfigService } from '@app/services/config.service'
import { CommonService } from '@app/services/common.service'
import { HeaderService } from '@app/services/header.service'
import { Business } from '@app/models/business'
import { ItemLocation } from '@app/models/itemlocation'
import { ModalComponent } from '@app/components/modal/modal.component'
import { FormMessage } from '@app/models/form-message'
import { User } from '@app/models/user'

@Component({
    selector: 'app-itemlocationadmin',
    templateUrl: './itemlocationadmin.component.html',
    styleUrls: ['./itemlocationadmin.component.scss'],
})
export class ItemLocationAdminComponent implements OnInit {
    itemForm: FormGroup

    itemLocations: ItemLocation[]
    currentLocation: ItemLocation
    locationOptions: SelectItem[] = []
    selectedLocation: SelectItem
    optionsInitialized: boolean = false

    business: Business
    user: User
    errorMessage: string
    showError = false
    messageError: any
    formMessage: [{}] = [{}] // = [{severity:'info', summary:'Info Message', detail:'system is setup'}];
    initialized: boolean
    dataReady: boolean

    constructor(
        private dataService: DataService,
        private configService: ConfigService,
        private commonService: CommonService,
        private messageService: MessageService,
        private headerService: HeaderService,
        private primengConfig: PrimeNGConfig,
        private dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: MatDialogConfig
    ) {}

    ngOnInit() {
        this.primengConfig.ripple = true
        this.headerService.setTitle('Item Locations Admin')
        this.headerService.setPageDescription(
            'maintain locations where items are kept, such as the kitchen, front, and other places'
        )
        this.dataService.adminItemLocationsSubscribe.subscribe((data) => {
            if (data.length) {
                this.itemLocations = data
                this.locationOptions = this.commonService.mapItemsToSelect(
                    this.itemLocations
                )
                this.currentLocation = this.itemLocations[0]
                this.selectedLocation = this.locationOptions[0]
                this.optionsInitialized = true
                this.dataReady = true
                this.buildForm()
            }
        })

        this.dataService.setBusiness().subscribe((data) => {
            this.business = data
        })

        this.dataService.user.subscribe((data) => {
            this.user = data
        })
    }

    buildForm() {
        this.itemForm = new FormGroup({
            name: new FormControl(
                this.currentLocation.name,
                Validators.required
            ),
            visible: new FormControl(this.currentLocation.visible),
            description: new FormControl(this.currentLocation.notes),
            id: new FormControl(this.currentLocation.id),
            businessId: new FormControl(this.currentLocation.businessId),
        })
    }

    getItemLocation(evt) {
        this.currentLocation = _.find(this.itemLocations, (o: ItemLocation) => {
            return o.id === evt.value.value
        })
        this.buildForm()
    }

    getDeleteLocation(id: number): ItemLocation {
        let location = _.find(this.itemLocations, (location: ItemLocation) => {
            return location.id === id
        })
        return location
    }

    showDeleteModal(itemForm: ItemLocation) {
        let location: ItemLocation = itemForm
        const modifyDate = this.commonService.getDate()
        const locationName = location.name
        const locationId = location.id
        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            autoFocus: true,
            hasBackdrop: true,
            panelClass: 'app-modal',
            data: {
                apiUrl: this.dataService.itemLocationApi,
                modifyDate,
                modifyBy: this.user.name,
                dialogMessage:
                    'Are you sure you want to delete ' + location.name + '?',
                warningMessage: 'This cannot be undone.',
                headerMessage: 'Category Deletion Confirmation',
                locationId,
                locationName,
            },
        })

        dialogRef.afterClosed().subscribe((result) => {
            if (result && result.event === 'delete') {
                let location = this.getDeleteLocation(result.data.locationId)
                location.softDelete = true
                this.dataService
                    .updateItemLocation(location)
                    .subscribe((data) => {
                        const deletedLocation = data
                        _.remove(
                            this.itemLocations,
                            (location: ItemLocation) => {
                                return location.id === deletedLocation.id
                            }
                        )
                        this.locationOptions =
                            this.commonService.mapItemsToSelect(
                                this.itemLocations
                            )
                        this.dataService.updateItemLocations()
                        this.buildForm()
                        this.generateItemMessage(data)
                    })
            }
        })
    }

    generateItemMessage(data: any) {
        let severity = 'success'
        if (data.status === 2) {
            severity = 'error'
        }
        let message = {
            severity: severity,
            summary: data.message,
            detail: '',
        }
        this.showMessage(message)
    }

    showMessage(data: FormMessage) {
        this.messageService.add(data)
        window.setTimeout(() => {
            this.messageService.clear()
        }, 3000)
    }

    addNewItem() {
        let location = new ItemLocation({
            id: 0,
            name: 'New Item Location',
            businessId: this.business.id,
            notes: '',
            visible: true,
            softDelete: false,
            modifyBy: this.user.name,
            modifyDate: new Date(),
        })
        this.dataService.saveItemLocation(location).subscribe((data) => {
            location.id = data.id
            this.dataService.updateItemLocations()
            this.currentLocation = location
            this.generateItemMessage(data)
            this.buildForm()
        })
    }

    saveForm(itemForm: FormGroup) {
        let location: ItemLocation = itemForm.value
        location.modifyDate = new Date()
        location.modifyBy = this.user.name
        if (location.id > 0 || location.id) {
            this.dataService.updateItemLocation(location).subscribe((data) => {
                this.currentLocation = location
                this.dataService.updateItemLocations()
                this.generateItemMessage(data)
            })
        } else {
            this.dataService.saveCategory(location).subscribe((data) => {
                this.currentLocation = data
                this.dataService.updateCategories()
                this.generateItemMessage(data)
            })
        }
    }
}
