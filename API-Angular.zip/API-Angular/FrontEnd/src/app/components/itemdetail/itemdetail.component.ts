import { Component, OnInit } from '@angular/core'

@Component({
    selector: 'app-itemdetail',
    templateUrl: './itemdetail.component.html',
    styleUrls: ['./itemdetail.component.scss'],
})
export class ItemdetailComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
