import { Component, Inject, Input, OnInit, Optional } from '@angular/core'
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'

@Component({
    selector: 'app-modal',
    templateUrl: './modal.component.html',
    styleUrls: ['./modal.component.scss'],
})
export class ModalComponent implements OnInit {
    apiUrl: string
    actionMessage: string

    constructor(
        public dialogRef: MatDialogRef<ModalComponent>,
        @Optional() @Inject(MAT_DIALOG_DATA) public data: any
    ) {
        this.apiUrl = data.apiUrl
    }

    ngOnInit(): void {}

    public closeModal() {
        this.dialogRef.close()
    }

    public deleteItem() {
        this.dialogRef.close({ event: 'delete', data: this.data })
    }
}
