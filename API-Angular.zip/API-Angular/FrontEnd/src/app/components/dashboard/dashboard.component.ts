import { BehaviorSubject, Subscription } from 'rxjs'
import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import _ from 'lodash'
import { DataService } from '@app/services/data.service'

import { PastList } from '@app/models/pastlist'
import { Utilities } from '@app/utilities/utilities'
import { Item } from '@app/models/item'

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initializedSubscribe = this._initialized.asObservable()
    private initializedSubscription: Subscription
    initialized: boolean = false

    name: string
    pastLists: PastList[]
    autoCompleteItems: Item[]
    filteredItems: Item[]
    filteredItemsComplete: boolean = false
    autoCompleteResults: Item[]
    selectedAutoCompleteItem: Item
    quickViewItems: Item[]
    quickViewItemsComplete: boolean = false
    businessId: number
    loading: boolean = true
    autocompleteSelected: boolean
    itemUpdated: boolean

    constructor(
        private dataService: DataService,
        private router: Router,
        private utilities: Utilities
    ) {}

    ngOnInit(): void {
        this.dataService.initializedSubscribe.subscribe((data) => {
            if (data) {
                this.initialize()
            }
        })
    }

    public initialize() {
        this.dataService.itemsSubscribe.subscribe((data) => {
            this.filteredItems = data
            this.autoCompleteItems = data

            _.forEach(this.filteredItems, (item: Item) => {
                if (!item.currentOnHand) {
                    item.currentOnHand = 0
                }
            })

            this.quickViewItems = _.filter(this.filteredItems, (item: Item) => {
                return item.quickView === true
            })

            this.initialized = true
            this.loading = false
        })
    }

    formatUom(item: Item) {
        if (!item.unitOfMeasure) {
            return ''
        }
        return this.utilities.formatUnitOfMeasure(item)
    }

    formatUnitOfMeasureAutoComplete(item: Item) {
        if (!item.unitOfMeasure) {
            return ''
        }
        return this.utilities.formatUnitOfMeasureAutoComplete(item)
    }

    filterItems(event) {
        this.filteredItems = this.filterAutoCompleteItems(event.query)
    }

    filterAutoCompleteItems(query: String): Item[] {
        return _.filter(this.autoCompleteItems, (o: Item) => {
            return o.name.toLowerCase().indexOf(query.toLowerCase()) === 0
        })
    }

    updateItem(item: Item) {
        this.dataService.updateItem(item).subscribe((data) => {
            if (item.currentOnHand < item.minimumAmount) {
                let listItem = this.dataService.mapItemToListItem(item)
                this.dataService.upsertListItem(listItem)
            }
        })
    }

    goPage(path) {
        this.router.navigate([path])
    }

    goToPastList(pastList: PastList) {
        console.log(pastList.listId)
        console.log(pastList.listDate)
    }

    takeInventory() {
        this.router.navigate(['inventorylist'])
    }
}
