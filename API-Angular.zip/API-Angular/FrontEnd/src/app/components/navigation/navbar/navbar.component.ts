import { Subscription } from 'rxjs'
import { Component, OnInit, OnDestroy } from '@angular/core'
import { AuthenticationService } from '@app/auth'

// todo: link is below to finish setting up mobile responsive menu
// https://medium.com/@edigleyssonsilva/bulma-css-framework-with-angular-6-responsive-menu-and-navbar-burger-dff747ed2dc1
@Component({
    selector: 'app-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit, OnDestroy {
    isAuthenticated: boolean
    subscription: Subscription

    constructor(private authService: AuthenticationService) {}

    ngOnInit() {
        this.subscription = this.authService.userLoaded$.subscribe(
            (status) => (this.isAuthenticated = status)
        )
    }

    login() {
        this.authService.triggerSignIn()
    }

    async logout() {
        await this.authService.triggerSignOut()
    }

    ngOnDestroy() {
        // prevent memory leak when component is destroyed
        this.subscription.unsubscribe()
    }
}
