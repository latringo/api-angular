import { Component, Inject, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogConfig,
} from '@angular/material/dialog'
import { BehaviorSubject } from 'rxjs'
import _ from 'lodash'
import { SelectItem, MessageService, PrimeNGConfig } from 'primeng/api'

import { DataService } from '@app/services/data.service'
import { ConfigService } from '@app/services/config.service'
import { CommonService } from '@app/services/common.service'
import { HeaderService } from '@app/services/header.service'

import { Category } from '@app/models/category'
import { Supplier } from '@app/models/supplier'
import { ItemLocation } from '@app/models/itemlocation'
import { Item } from '@app/models/item'
import { FormMessage } from '@app/models/form-message'
import { UnitOfMeasure } from '@app/models/unitofmeasure'
import { ModalComponent } from '@app/components/modal/modal.component'

@Component({
    selector: 'app-itemadmin',
    templateUrl: './itemadmin.component.html',
    styleUrls: ['./itemadmin.component.scss'],
})
export class ItemAdminComponent implements OnInit {
    private _initialized = new BehaviorSubject<boolean>(false)
    readonly initializedSubscribe = this._initialized.asObservable()

    initialized: boolean = false

    modalData: MatDialogConfig
    items: Item[]

    itemOptions: SelectItem[]

    currentItem: Item
    currentItems: Item[]
    currentItemCopy: Item

    categories: Category[]
    currentCategory: Category
    categoryOptions: SelectItem[] = []
    selectedCategory: SelectItem

    suppliers: Supplier[]
    supplier: Supplier
    supplierOptions: SelectItem[] = []
    selectedSupplier: SelectItem

    itemLocations: ItemLocation[]
    itemLocation: ItemLocation
    itemLocationOptions: SelectItem[] = []
    selectedItemLocation: SelectItem

    unitsOfMeasures: UnitOfMeasure[]
    unitOfMeasure: UnitOfMeasure
    unitsOfMeasureOptions: SelectItem[] = []
    selectedUnitOfMeasure: SelectItem

    itemsInitialized: boolean = false
    shoppingListItemsInitialized: boolean = false
    categoriesInitialized: boolean = false
    suppliersInitialized: boolean = false
    itemLocationsInitialized: boolean = false
    unitsOfMeasureInitialized: boolean = false

    dataReady: boolean
    statusMessage: string
    itemForm: FormGroup
    modalDialogOptions: MatDialogConfig
    formMessage: [{}] = [{}] // = [{severity:'info', summary:'Info Message', detail:'system is setup'}];

    constructor(
        private dataService: DataService,
        private configService: ConfigService,
        private commonService: CommonService,
        private headerService: HeaderService,
        private primengConfig: PrimeNGConfig,
        private messageService: MessageService,
        private dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: MatDialogConfig
    ) {}

    ngOnInit() {
        this.primengConfig.ripple = true
        this.headerService.setTitle('Item Admin')
        this.headerService.setPageDescription(
            'maintain restaurant items by setting categories, suppliers and other details'
        )

        this.dataService.adminItemsSubscribe.subscribe((data) => {
            if (data.length) {
                this.items = data
                this.currentItems = this.items
                // this._items.next(this.items)
                this.itemsInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.categoriesSubscribe.subscribe((data) => {
            if (data.length) {
                this.categories = data
                this.categoryOptions = this.commonService.mapItemsToSelect(
                    this.categories
                )
                this.selectedCategory = this.categoryOptions[0]
                this.categoriesInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.suppliersSubscribe.subscribe((data) => {
            if (data.length) {
                this.suppliers = _.sortBy(data, ['id'])
                this.supplierOptions = this.commonService.mapItemsToSelect(
                    this.suppliers
                )
                this.suppliersInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.itemLocationsSubscribe.subscribe((data) => {
            if (data.length) {
                this.itemLocations = data
                this.itemLocationOptions = this.commonService.mapItemsToSelect(
                    this.itemLocations
                )
                this.selectedItemLocation = this.itemLocationOptions[0]
                this.itemLocationsInitialized = true
                this.checkInitialized()
            }
        })

        this.dataService.unitsOfMeasureSubscribe.subscribe((data) => {
            if (data.length) {
                this.unitsOfMeasures = data
                this.unitsOfMeasureOptions =
                    this.commonService.mapItemsToSelect(this.unitsOfMeasures)
                this.unitsOfMeasureInitialized = true
                this.checkInitialized()
            }
        })
    }

    checkInitialized() {
        let initialized =
            this.itemsInitialized &&
            this.categoriesInitialized &&
            this.suppliersInitialized &&
            this.itemLocationsInitialized &&
            this.unitsOfMeasureInitialized

        this.dataReady = initialized
        if (initialized) {
            this.setCurrentItems()
            this.buildForm()
        }
    }

    buildForm() {
        this.itemForm = new FormGroup({
            id: new FormControl(this.currentItem.id),
            name: new FormControl(this.currentItem.name, Validators.required),
            categoryId: new FormControl(
                this.currentItem.category.id,
                Validators.required
            ),
            unitOfMeasureId: new FormControl(
                this.currentItem.unitOfMeasure.id,
                Validators.required
            ),
            supplierId: new FormControl(
                this.currentItem.supplier.id,
                Validators.required
            ),
            itemLocationId: new FormControl(
                this.currentItem.itemLocation.id,
                Validators.required
            ),
            purchaseAmount: new FormControl(
                this.currentItem.purchaseAmount,
                Validators.required
            ),
            minimumAmount: new FormControl(
                this.currentItem.minimumAmount,
                Validators.required
            ),
            quickView: new FormControl(this.currentItem.quickView),
            visible: new FormControl(this.currentItem.visible),
            upc: new FormControl(this.currentItem.upc),
            softDelete: new FormControl(this.currentItem.softDelete),
            modifyDate: new FormControl(this.commonService.getDate()),
            modifyBy: new FormControl(this.configService.getUser().id),
        })
        this.dataReady = true
    }

    setCurrentItems() {
        this.currentItems = _.filter(this.items, (o: Item) => {
            return (
                o.itemLocationId === this.selectedItemLocation.value &&
                o.categoryId === this.selectedCategory.value
            )
        })

        this.itemOptions = this.commonService.mapItemsToSelect(
            this.currentItems
        )

        if (!this.currentItem || !this.currentItem.newItem) {
            this.currentItem = this.currentItems[0]
        }
    }

    getItem(evt) {
        this.currentItem = _.find(this.items, (o: Item) => {
            return o.id === evt.value.value
        })
        this.buildForm()
    }

    getDeleteItem(id: number): Item {
        let item = _.find(this.items, (item: Item) => {
            return item.id === id
        })
        return item
    }

    showDeleteModal(itemForm: Item) {
        let item: Item = itemForm
        const modifyDate = this.commonService.getDate()
        const itemName = item.name
        const itemId = item.id
        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            autoFocus: true,
            hasBackdrop: true,
            panelClass: 'app-modal',
            data: {
                apiUrl: this.dataService.itemApi,
                modifyDate,
                modifyBy: this.configService.getUser().id,
                dialogMessage:
                    'Are you sure you want to delete ' + item.name + '?',
                warningMessage: 'This cannot be undone.',
                headerMessage: 'Item Deletion Confirmation',
                itemId,
                itemName,
            },
        })

        dialogRef.afterClosed().subscribe((result) => {
            if (result && result.event === 'delete') {
                // let item: Item = result.data
                let item = this.getDeleteItem(result.data.itemId)
                item.softDelete = true
                this.dataService.updateItem(item).subscribe((data) => {
                    const deletedItem: Item = data
                    _.remove(this.items, (item: Item) => {
                        return item.id === deletedItem.id
                    })
                    this.itemOptions = this.commonService.mapItemsToSelect(
                        this.items
                    )
                    this.dataService.updateItems()
                    this.buildForm()
                    this.generateItemMessage(data)
                })
            }
        })
    }

    generateItemMessage(data: any) {
        let severity = 'success'
        if (data.status === 2) {
            severity = 'error'
        }
        let message = {
            severity: severity,
            summary: data.message,
            detail: '',
        }
        this.showMessage(message)
    }

    showMessage(data: FormMessage) {
        this.messageService.add(data)
        window.setTimeout(() => {
            this.messageService.clear()
        }, 3000)
    }

    getCurrentCategory(): Category {
        let category = _.find(this.categories, (category: Category) => {
            return category.id === this.selectedCategory.value
        })
        return category
    }

    addNewItem() {
        let item = new Item({
            name: 'New Item',
            category: this.getCurrentCategory(),
            unitOfMeasure: this.unitsOfMeasures[0],
            supplier: this.suppliers[0],
            itemLocation: this.itemLocations[0],
            minimumAmount: 0,
            purchaseAmount: 0,
            quickView: false,
            visible: true,
            upc: null,
            softDelete: false,
            warning: false,
            currentOnHand: 0,
            currentPurchasedAmount: 0,
            currentCost: 0.0,
            currentNotes: '',
            createDate: new Date(),
            createBy: this.configService.getUser().id,
            modifyDate: new Date(),
            modifyBy: this.configService.getUser().id,
        })
        this.dataService.saveItem(item).subscribe((data) => {
            item.id = data.id
            item.newItem = true
            this.dataService.updateItems()
            this.currentItem = item
            this.generateItemMessage(data)
            this.buildForm()
        })
    }

    saveForm(itemForm: FormGroup) {
        let item: Item = itemForm.value
        if (item.id > 0 || item.id) {
            item.modifyDate = new Date()
            this.dataService.updateItem(item).subscribe((data) => {
                this.currentItem = item
                this.currentItem.newItem = false
                this.dataService.updateItems()
                this.generateItemMessage(data)
            })
        } else {
            this.dataService.saveItem(item).subscribe((data) => {
                this.currentItem = data
                this.dataService.updateItems()
                this.generateItemMessage(data)
            })
        }
    }
}
