﻿import { Component, OnInit } from '@angular/core'

@Component({
    selector: 'app-spinner-waiter',
    templateUrl: './spinner.component.html',
    styleUrls: ['./spinner.component.scss'],
})
export class SpinnerWaiterComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
