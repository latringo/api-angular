import { NgModule } from "@angular/core";
import { routes } from "./data/routes";

import { Routes, RouterModule } from "@angular/router";

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
