﻿import { NgModule } from '@angular/core'
import { DropdownModule } from 'primeng/dropdown'
import { ListboxModule } from 'primeng/listbox'
import { AutoCompleteModule } from 'primeng/autocomplete'
import { InputSwitchModule } from 'primeng/inputswitch'
import { InputTextModule } from 'primeng/inputtext'

@NgModule({
    declarations: [],
    imports: [
        DropdownModule,
        AutoCompleteModule,
        ListboxModule,
        InputSwitchModule,
        InputTextModule,
    ],
    providers: [],
})
export class PrimeNGModule {}
