import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { UserManager, User } from "oidc-client";
import { ReplaySubject } from "rxjs";
import { catchError } from "rxjs/operators";
import { environment } from "../../environments/environment";
import { BaseService } from "./base.service";

@Injectable({
  providedIn: "root",
})
export class AuthenticationService extends BaseService {
  public userManager: UserManager = new UserManager(
    environment.openIdConnectSettings
  );
  private currentUser: User;

  userLoaded$ = new ReplaySubject<boolean>(1);

  constructor(private router: Router) {
    super();

    this.userManager.clearStaleState();

    this.userManager.events.addUserLoaded((user) => {
      if (!environment.production) {
        console.log("User loaded.", user);
      }
      this.currentUser = user;
      this.userLoaded$.next(true);
    });

    this.userManager.events.addUserUnloaded(() => {
      if (!environment.production) {
        console.log("User unloaded");
      }
      this.currentUser = null;
      this.userLoaded$.next(false);
    });

    this.loadUser();
  }

  get userAvailable(): boolean {
    return this.currentUser != null;
  }
  GetUser() {
    return this.currentUser;
  }
  GetUserId(): string {
    return this.currentUser.profile.sub;
  }

  RefreshClaims() {
    this.userManager.signinSilent();
  }

  loadUser() {
    // loads user from local state in the case of page refresh
    return this.userManager.getUser().then((user) => {
      if (!!user && !user.expired) {
        this.currentUser = user;
        // not sure if we need the next below,
        // as it seems to fire also from the userloaded event in the constructor
        this.userLoaded$.next(true);
      }
    });
  }

  triggerSignIn(emailAddress?: string) {
    this.userManager
      .signinRedirect({
        extraQueryParams: {
          emailAddress: emailAddress,
        },
      })
      .then(function () {
        if (!environment.production) {
          console.log("Redirection to signin triggered.");
        }
      });
  }

  async handleCallback() {
    return this.userManager.signinRedirectCallback();
  }

  handleSilentCallback() {
    console.log("Callback after silent signin handled.");
    // make sure to set this flag to true, so the oidc callback can handle whether to do a redirect or not
    this.userManager.signinSilentCallback();
  }

  triggerSignOut() {
    // see https://stackoverflow.com/a/44726272/2349252 for why id_token_hint needs to be passed along
    // otherwise, PostLogoutRedirectUri is null in Identity Service Account Controller.

    this.router.navigate(["/account/logout"]);

    this.userManager
      .signoutRedirect({ id_token_hint: this.currentUser.id_token })
      .then(function (resp) {
        if (environment.production) {
          console.log("Redirection to sign out triggered.", resp);
        }
      });
  }

  getAccessToken() {
    return this.userManager.getUser().then((user) => {
      if (!!user && !user.expired) {
        return user.access_token;
      } else {
        return null;
      }
    });
  }
}

//   get authorizationHeaderValue(): string {
//     return `${this.currentUser.token_type} ${this.currentUser.access_token}`;
//   }

//   get name(): string {
//     return this.currentUser != null ? this.currentUser.profile.SecureEmailAddress : '';
//   }

//   logout() {
//     // see https://stackoverflow.com/a/44726272/2349252 for why id_token_hint needs to be passed along
//     // otherwise, PostLogoutRedirectUri is null in Identity Service Account Controller.
//     this._userManager.signoutRedirect({ id_token_hint: this.currentUser.id_token });
//   }

//   getAccessToken() {
//     return this._userManager.getUser().then((user) => {
//       if (!!user && !user.expired) {
//         return user.access_token;
//       } else {
//         return null;
//       }
//     });
//   }
// }
