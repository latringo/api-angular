import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { LocalStorageService } from '@app/services/localstorage.service'
import { environment } from '@env/environment'
import { AuthenticationService } from '..'

@Component({
    selector: 'app-auth-callback',
    templateUrl: './auth-callback.component.html',
    styleUrls: ['./auth-callback.component.scss'],
})
export class AuthCallbackComponent implements OnInit {
    error: boolean

    constructor(
        private authService: AuthenticationService,
        private router: Router,
        private localStorageService: LocalStorageService
    ) {}

    ngOnInit() {
        // fixes an issue where the callback doesn't redirect...url changes but actual route doesn't go to new page
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false
        }
        this.router.onSameUrlNavigation = 'reload'

        this.authService.handleCallback().then((user) => {
            if (user) {
                const returnUrl = this.localStorageService.get(
                    environment.returnUrlKey
                )

                this.router.navigate(['./dashboard'])

                this.localStorageService.remove(environment.returnUrlKey)

                if (!environment.production) {
                    console.log('Callback after signin handled.')
                }
            } else {
                if (!environment.production) {
                    this.error = true
                    console.log("An error happened: user wasn't loaded.")
                }
            }
        })
    }
}
