import {
    Router,
    CanActivate,
    ActivatedRouteSnapshot,
    RouterStateSnapshot,
} from '@angular/router'
import { Logger } from './../@core/logger.service'
import { Injectable } from '@angular/core'
import { AuthenticationService } from './authentication.service'
import { environment } from '../../environments/environment'
import { LocalStorageService } from '@app/services/localstorage.service'

// adapted from https://stackoverflow.com/a/40021645/2349252

const log = new Logger('AuthenticationGuard')

@Injectable({
    providedIn: 'root',
})
export class AuthenticationGuard implements CanActivate {
    constructor(
        private authService: AuthenticationService,
        private localStorageService: LocalStorageService
    ) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        // https://stackoverflow.com/a/39747451/2349252
        // for redirect

        let url: string = state.url

        return this.checkLogin(url)
    }

    persist(key: string, value: any) {
        this.localStorageService.set(key, value)
    }

    checkLogin(url: string): any {
        return this.authService.loadUser().then(() => {
            if (this.authService.userAvailable) {
                return true
            }

            // Store the attempted URL for redirecting
            this.persist(environment.returnUrlKey, url)

            // Navigate to the login page with extras
            // this.router.navigate(['/login']);
            // todo: make sure to add redirect url
            log.debug(
                'Not authenticated, redirecting and adding redirect url...'
            )
            this.authService.triggerSignIn()
            return false
        })
    }
}
