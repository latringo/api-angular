import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LogoutComponent } from "@app/account/logout/logout.component";

const routes: Routes = [{ path: "logout", component: LogoutComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AuthRoutingModule {}
