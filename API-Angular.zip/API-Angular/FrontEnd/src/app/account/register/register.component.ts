import { Component, OnInit } from "@angular/core";
import { finalize, timeout } from "rxjs/operators";
import { AuthenticationService } from "@app/auth";
import { UserRegistration } from "@app/models/user.registration";
import { UserService } from "../user.service";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.scss"],
})
export class RegisterComponent implements OnInit {
  isLoading = false;

  success: boolean = false;
  error: string;
  userRegistration: UserRegistration = { name: "", email: "", password: "" };
  submitted = false;

  constructor(
    private authService: AuthenticationService,
    private userService: UserService
  ) {}

  ngOnInit() {}

  onSubmit() {
    this.userService
      .register(this.userRegistration, null)
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe(
        (result) => {
          if (result) {
            this.success = true;
          }
        },
        (error) => {
          this.error = error;
        }
      );
  }
}

export enum AccountSelection {
  Unselected = 0,
  InviteCode = 1,
}
