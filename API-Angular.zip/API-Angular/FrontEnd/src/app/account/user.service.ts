import { Injectable } from "@angular/core";
import { BaseService } from "@app/auth/base.service";
import { HttpService } from "@core/http/http.service";
import { environment } from "@env/environment";
import { of } from "rxjs";
import { map, catchError } from "rxjs/operators";
// import { AccountSelection } from 'src/app/account/register/register.component';
import { AuthenticationService } from "src/app/auth";

@Injectable({
  providedIn: "root",
})
export class UserService extends BaseService {
  constructor(
    private httpService: HttpService,
    private authService: AuthenticationService
  ) {
    super();
  }

  getUserName(): string {
    return this.authService.GetUser().profile.given_name;
  }

  // public AccountTypeAsString(selection: AccountSelection): string {
  //   let result = '';
  //   switch (selection) {
  //     case AccountSelection.Unselected:
  //       result = "";
  //       break;
  //     case AccountSelection.InviteCode:
  //       result = "InviteCode";
  //       break;
  //     default:
  //       break;
  //   }
  //   return result;
  // }

  checkIfUserNameOrEmailAlreadyExists(userNameOrEmail: string) {
    return this.httpService
      .get(
        `${environment.openIdConnectSettings.authority}account/checkifusernameexists/${userNameOrEmail}`
      )
      .pipe(
        map((body) => body),
        catchError((e) => of("Error, could not load user info :-(" + e.message))
      );
  }

  register(userRegistration: any, accountType: string) {
    return this.httpService
      .post(
        `${environment.openIdConnectSettings.authority}account/register?`,
        userRegistration
      )
      .pipe(catchError(this.handleError));
  }

  getClaim(name: string) {
    console.log("user", this.authService.GetUser().profile);
    return this.authService.GetUser().profile["AccountType"];
  }

  getUser() {
    return 1;
  }
}
