import { Component, OnInit } from "@angular/core";
import { AuthenticationService } from "@app/auth";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  constructor(private auth: AuthenticationService) {
    auth.triggerSignIn();
  }

  ngOnInit(): void {}
}
