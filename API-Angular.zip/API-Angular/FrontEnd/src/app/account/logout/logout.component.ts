import { Component, OnDestroy, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-logout",
  templateUrl: "./logout.component.html",
  styleUrls: ["./logout.component.scss"],
})
export class LogoutComponent implements OnInit, OnDestroy {
  timeout;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.timeout = setTimeout(() => {
      this.router.navigate(["/"]);
    }, 2500);
  }

  ngOnDestroy() {
    clearTimeout(this.timeout);
  }
}
