import { MenuComponent } from "./../components/menu/menu.component";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";

import { AuthModule } from "@app/auth";
import { ShellComponent } from "./shell.component";
import { HeaderComponent } from "@app/components/header/header.component";

@NgModule({
  imports: [CommonModule, AuthModule, RouterModule],
  exports: [HeaderComponent],
  declarations: [HeaderComponent, MenuComponent, ShellComponent],
})
export class ShellModule {}
