import { Injectable } from "@angular/core";
import {
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
} from "@angular/common/http";
import { of } from "rxjs";
import { tap } from "rxjs/operators";
import { CacheMapService } from "@app/interceptors/cache-map.service";
import { ConfigService } from "@app/services/config.service";

@Injectable()
export class CachingInterceptor implements HttpInterceptor {
  apiUrl: string;

  constructor(
    private cache: CacheMapService,
    private configService: ConfigService
  ) {
    this.apiUrl = this.configService.getApiUrl();
  }

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    if (!this.isRequestCachable(req)) {
      return next.handle(req);
    }

    const cachedResponse = this.cache.get(req);
    if (cachedResponse !== null) {
      return of(cachedResponse);
    }
    return next.handle(req).pipe(
      tap((event) => {
        if (event instanceof HttpResponse) {
          this.cache.put(req, event);
        }
      })
    );
  }

  private isRequestCachable(req: HttpRequest<any>) {
    return req.method === "GET" && req.url.indexOf(this.apiUrl) > -1;
  }
}
