import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { LoggingInterceptor } from "@app/interceptors/logging.interceptor";
// import {CachingInterceptor} from '@app/interceptors/cachinginterceptor.interceptor';

export const httpInterceptorProviders = [
  { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptor, multi: true },
  // {provide: HTTP_INTERCEPTORS, useClass: CachingInterceptor, multi: true}
];
