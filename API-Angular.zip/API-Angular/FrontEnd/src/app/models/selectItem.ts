﻿export class SelectItem {
    value: number
    label: string

    public constructor(init?: Partial<SelectItem>) {
        Object.assign(this, init)
    }
}
