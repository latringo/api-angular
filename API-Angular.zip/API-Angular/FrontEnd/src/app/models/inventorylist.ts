import { Item } from './Item'

export class InventoryList {
    id: number
    businessId: number
    inventoryDate: Date
    userId: number
    items: Item[]
    modifyBy: string
    modifyDate: Date

    public constructor(init?: Partial<InventoryList>) {
        Object.assign(this, init)
    }
}
