export class ItemHistory {
    public id: number
    public itemId: number
    public onHand: any
    public purchasedAmount: number
    public cost: number
    public notes: string
    public createDate: Date
    public createBy: Date
    public modifyDate: Date
    public modifyBy: number

    public constructor(init?: Partial<ItemHistory>) {
        Object.assign(this, init)
    }
}
