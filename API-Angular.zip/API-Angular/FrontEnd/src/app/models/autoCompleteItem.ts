import { ItemHistory } from '@app/models/itemhistory'
import { UnitOfMeasure } from './unitofmeasure'

export class AutoCompleteItem {
    public id: number
    public name: string
    public unitOfMeasure: UnitOfMeasure
    public unitOfMeasureId: number
    public minimumAmount: number
    public warning: boolean
    public onHand: number
    public currentItemData: ItemHistory

    public constructor(init?: Partial<AutoCompleteItem>) {
        Object.assign(this, init)
    }
}
