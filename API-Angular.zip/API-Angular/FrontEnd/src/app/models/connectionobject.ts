export class ConnectionObject {
    status: string
    isConnected: boolean
}
