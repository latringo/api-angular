﻿export class UnitOfMeasure {
    public id: number
    public name: string
    public visible: boolean
    public softDelete: boolean

    constructor(init?: Partial<UnitOfMeasure>) {
        Object.assign(this, init)
    }
}
