import { Supplier } from '@app/models/supplier'
import { UnitOfMeasure } from '@app/models/unitofmeasure'
import { Category } from '@app/models/category'
import { ItemLocation } from '@app/models/itemlocation'

export class Item {
    public objectType: Item
    public id: number
    public name: string
    public itemDataId: number
    public category: Category
    public categoryId: number
    public unitOfMeasure: UnitOfMeasure
    public unitOfMeasureId: number
    public supplier: Supplier
    public supplierId: number
    public itemLocation: ItemLocation
    public itemLocationId: number
    public amountToBuy: number
    public minimumAmount: number
    public purchaseAmount: number
    public quickView: boolean
    public visible: boolean
    public upc: string
    public softDelete: boolean
    public warning: boolean
    public currentOnHand: number
    public currentPurchasedAmount: number
    public currentCost: number
    public currentNotes: string
    public createDate: Date
    public createBy: number
    public modifyBy: number
    public modifyDate: Date
    public newItem: boolean

    public constructor(init?: Partial<Item>) {
        Object.assign(this, init)
    }
}
