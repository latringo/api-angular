export class ItemLocation {
    public id: number
    public name: string
    public notes: string
    public softDelete: boolean
    public visible: boolean
    public modifyBy: string
    public modifyDate: Date
    public businessId: number

    public constructor(init?: Partial<ItemLocation>) {
        Object.assign(this, init)
    }
}
