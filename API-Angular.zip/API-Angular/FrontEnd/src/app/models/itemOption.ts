﻿export class ItemOption {
    value: number
    label: string

    public constructor(init?: Partial<ItemOption>) {
        Object.assign(this, init)
    }
}
