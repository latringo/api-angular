export class PastList {
    public listId: number
    public listDate: Date

    public constructor(init?: Partial<PastList>) {
        Object.assign(this, init)
    }
}
