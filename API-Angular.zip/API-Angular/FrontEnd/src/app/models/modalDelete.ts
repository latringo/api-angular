﻿export class ModalDelete {
    showModal: boolean
    itemId: number

    public constructor(init?: Partial<ModalDelete>) {
        Object.assign(this, init)
    }
}
