export class Supplier {
    public id: number
    public businessId: number
    public name: string
    public contact: string
    public address: string
    public city: string
    public state: string
    public zip: number
    public email: string
    public website: string
    public visible: boolean
    public softDelete: boolean
    public notes: string
    public modifyBy: string
    public modifyDate: Date

    public constructor(init?: Partial<Supplier>) {
        Object.assign(this, init)
    }
}
