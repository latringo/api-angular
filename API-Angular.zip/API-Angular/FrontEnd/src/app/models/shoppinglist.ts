import { User } from './user'
import { ShoppingListItem } from '@app/models/shoppinglistitem'

export class ShoppingList {
    public id: number
    public name: string
    public businessId: number
    public notes: string
    public listDate: string
    public completed: boolean
    public softDelete: boolean
    public modifyBy: number
    public modifyDate: string
    public completedDate: string
    public user: User
    public listCount: number
    public listItems: ShoppingListItem[]

    public constructor(init?: Partial<ShoppingList>) {
        Object.assign(this, init)
    }
}
