export class FormMessage {
    public severity: string
    public summary: string
    public detail: string

    public constructor(init?: Partial<any>) {
        Object.assign(this, init)
    }
}
