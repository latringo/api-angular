import { Item } from '@app/models/item'
export class ShoppingListItem {
    public id: number
    public shoppingListId: number
    public itemId: number
    public itemName: string
    public categoryId: number
    public supplierId: number
    public unitOfMeasureId: number
    public purchaseAmount: number
    public onHand: number
    public purchasedAmount: number
    public costPerUnit: number
    public notes: string
    public categoryName: string
    public supplierName: string
    public unitOfMeasureName: string
    public completed: boolean

    public constructor(init?: Partial<ShoppingListItem>) {
        Object.assign(this, init)
    }
}
