﻿export class ModalData {
    public disableClose: boolean
    public autoFocus: boolean
    public hasBackdrop: boolean
    public panelClass: string
    public height: string
    public width: string
    public data: any

    public constructor(init?: Partial<ModalData>) {
        Object.assign(this, init)
    }
}
