﻿import { UnitOfMeasure } from './unitofmeasure'
export class ItemQuickView {
    public itemId: number
    public itemName: string
    public unitOfMeasure: UnitOfMeasure
    public onHand: number
    public minimumAmount: number
    public warning: boolean

    public constructor(init?: Partial<ItemQuickView>) {
        Object.assign(this, init)
    }
}
