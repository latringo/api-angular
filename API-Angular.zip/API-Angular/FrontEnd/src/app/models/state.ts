export class State {
    public id: number
    public abbreviation: string
    public name: string
}
