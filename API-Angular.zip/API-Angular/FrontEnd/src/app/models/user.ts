﻿import { Business } from '@app/models/business'

export class User {
    public id: number
    public name: string
    public email: string
    public business: Business
    public businessId: number
    public modifyBy: string
    public modifyDate: Date
    public softDelete: boolean

    public constructor(init?: Partial<User>) {
        Object.assign(this, init)
    }
}
