export class Category {
    public id: number
    public name: string
    public businessId: number
    public notes: string
    public visible: boolean
    public softDelete: boolean
    public modifyBy: string
    public modifyDate: Date

    public constructor(init?: Partial<Category>) {
        Object.assign(this, init)
    }
}
