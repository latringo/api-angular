export class Business {
    id: number
    businessName: string
    contact: string
    phone: string
    email: string
    website: string
    visible: boolean
    modifyBy: string
    modifyDate: Date

    public constructor(init?: Partial<Business>) {
        Object.assign(this, init)
    }
}
