import { AuthModule } from '@app/auth'
import { BrowserModule } from '@angular/platform-browser'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { NgModule } from '@angular/core'
import '@angular/compiler'
import { CommonModule } from '@angular/common'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module'
// import { ShellModule } from '@app/shell/shell.module';
import { Shell } from '@app/shell/shell.service'
// PrimeNg stuff
import { DropdownModule } from 'primeng/dropdown'
import { ListboxModule } from 'primeng/listbox'
import { AutoCompleteModule } from 'primeng/autocomplete'
import { InputSwitchModule } from 'primeng/inputswitch'
import { InputTextModule } from 'primeng/inputtext'
import { InputNumberModule } from 'primeng/inputnumber'
import { InputTextareaModule } from 'primeng/inputtextarea'
import { MessagesModule } from 'primeng/messages'
import { MessageModule } from 'primeng/message'
import { ProgressSpinnerModule } from 'primeng/progressspinner'
import { BlockUIModule } from 'primeng/blockui'

// Material Design
import {
    MatDialogModule,
    MAT_DIALOG_DATA,
    MatDialogRef,
} from '@angular/material/dialog'

import { HomeComponent } from '@app/components/home/home.component'
import { InventorylistComponent } from '@app/components/inventorylist/inventorylist.component'
import { AdminComponent } from '@app/components/admin/admin.component'
import { NavigationComponent } from '@app/components/navigation/navigation.component'
import { CategoryAdminComponent } from '@app/components/categoryadmin/categoryadmin.component'
import { ItemComponent } from '@app/components/item/item.component'
import { SettingsComponent } from '@app/components/user/settings/settings.component'
import { ProfileComponent } from '@app/components/user/profile/profile.component'
import { CategoriesComponent } from '@app/components/admin/categories/categories.component'
import { ItemsComponent } from '@app/components/admin/items/items.component'
import { SuppliersComponent } from '@app/components/admin/suppliers/suppliers.component'
import { ShoppinglistComponent } from '@app/components/shoppinglist/shoppinglist.component'
import { ItemdetailComponent } from '@app/components/itemdetail/itemdetail.component'
import { LostpasswordComponent } from '@app/components/account/password/lostpassword.component'
import { ChangepasswordComponent } from '@app/components/account/password/changepassword.component'
import { NavbuttonComponent } from '@app/components/commonui/navbutton/navbutton.component'
import { NavbarComponent } from '@app/components/navigation/navbar/navbar.component'
import { SidebarComponent } from '@app/components/sidebar/sidebar.component'
import { InventoryListItemComponent } from '@app/components/inventorylistitem/inventorylistitem.component'
import { ItemAdminComponent } from '@app/components/itemadmin/itemadmin.component'
import { ListingitemComponent } from '@app/components/listingitem/listingitem.component'
import { UserComponent } from '@app/components/admin/user/user.component'
import { ModalComponent } from '@app/components/modal/modal.component'
import { AdminPanelComponent } from '@app/components/adminpanel/adminpanel.component'
import { AuthCallbackComponent } from './auth/auth-callback/auth-callback.component'
import { CoreModule } from '@core'
import { DashboardComponent } from '@app/components/dashboard/dashboard.component'
import { SupplierAdminComponent } from '@app/components/supplieradmin/supplieradmin.component'
import { UnitsOfMeasureComponent } from '@app/components/unitsofmeasureadmin/unitsofmeasure.component'
import { ItemLocationAdminComponent } from '@app/components/itemlocationadmin/itemlocationadmin.component'
import { ReportsComponent } from '@app/components/reports/reports.component'
import { SpinnerWaiterComponent } from '@app/components/spinner/spinner-waiter.component'
import { ShellModule } from '@app/shell/shell.module'

import { MessageService } from 'primeng/api'
import { CacheMapService } from '@app/interceptors/cache-map.service'
import { DataService } from '@app/services/data.service'
import { LocalStorageService } from '@app/services/localstorage.service'

import { Cache } from '@app/interceptors/cache'
import { httpInterceptorProviders } from '@app/interceptors'
import { Utilities } from '@app/utilities/utilities'
@NgModule({
    declarations: [
        AuthCallbackComponent,
        HomeComponent,
        InventorylistComponent,
        AdminComponent,
        NavigationComponent,
        CategoryAdminComponent,
        UnitsOfMeasureComponent,
        ItemComponent,
        SettingsComponent,
        ProfileComponent,
        CategoriesComponent,
        ItemsComponent,
        SuppliersComponent,
        ShoppinglistComponent,
        ItemdetailComponent,
        LostpasswordComponent,
        ChangepasswordComponent,
        NavbuttonComponent,
        NavbarComponent,
        SidebarComponent,
        InventoryListItemComponent,
        ItemAdminComponent,
        ListingitemComponent,
        UserComponent,
        DashboardComponent,
        SupplierAdminComponent,
        ItemLocationAdminComponent,
        ReportsComponent,
        SpinnerWaiterComponent,
        ModalComponent,
        AdminPanelComponent,
    ],
    imports: [
        BrowserModule,
        AuthModule,
        HttpClientModule,
        CoreModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        InputTextareaModule,
        InputSwitchModule,
        InputTextModule,
        InputNumberModule,
        DropdownModule,
        AutoCompleteModule,
        ListboxModule,
        MessageModule,
        MessagesModule,
        ProgressSpinnerModule,
        BlockUIModule,
        MatDialogModule,
        AppRoutingModule,
        ShellModule,
        // must be imported as the last module as it contains the fallback route
    ],
    providers: [
        Shell /**/,
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        // RequestCache,{provide:HTTP_INTERCEPTORS, useClass:CachingInterceptor, multi: true},
        DataService,
        MessageService,
        LocalStorageService,
        Utilities,
        httpInterceptorProviders,
        CacheMapService,
        { provide: Cache, useClass: CacheMapService },
    ],
    // bootstrap: [ModalComponent],
    bootstrap: [HomeComponent],
})
export class AppModule {}
