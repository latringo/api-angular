﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Api.Controllers.api
{
    [Route("")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        // todo: This is used with AWS, as it checks to see if a 200 is returned,
        // which indicates that the system is healthy.  This is just basic
        // so the health check on amazon works
        [AllowAnonymous]
        public IActionResult Get()
        {
            return Ok();
        }

    }
}
