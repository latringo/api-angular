﻿using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class UnitsOfMeasureController : ControllerBase
    {
        private readonly Entities db;

        public UnitsOfMeasureController(Entities db)
        {
            this.db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UnitOfMeasure>>> GetUnitsOfMeasure()
        {
            return await db.UnitOfMeasures
                .Where(m => m.SoftDelete == false)
                .OrderBy(m => m.Name)
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<UnitOfMeasure>> GetUnitOfMeasure(int id)
        {
            var uom = await db.UnitOfMeasures.FindAsync(id);
            if(uom == null)
            {
                return NotFound();
            }
            return uom;
        }

        [HttpPost]
        public async Task<ActionResult<UnitOfMeasure>> PostUnitOfMeasure(UnitOfMeasure uom)
        {
            try
            {
                db.UnitOfMeasures.Add(uom);
                await db.SaveChangesAsync();
                return Ok(new { message = "Unit of Measure saved", status = "success", id = uom.Id });
            }
            catch (Exception)
            {
                return Ok(new { message = "An error occured", status = "error", id = uom.Id });
            }
        }

        [HttpPut]
        public async Task<IActionResult> PutUnitOfMeasure(int id, UnitOfMeasure uom)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { Message = "Form is invalid. Please check your entries and try again.", Status = "error" });
            }

            if(id != uom.Id)
            {
                return BadRequest(new { Message = "Bad Request", Status = "error" });
            }

            db.Entry(uom).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
                var message = "Unit of Measure saved";
                if(uom.SoftDelete)
                {
                    message = "Unit of Measure deleted";
                }

                return Ok(new { Message = message, Status = "success" });
            }
            catch (Exception)
            {
                return Ok(new { Message = "An error occured", Status = "error" });
            }
        }
    }
}
