﻿using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class ShoppingListItemsController : ControllerBase
    {
        private readonly Entities db;

        public ShoppingListItemsController(Entities _db)
        {
            db = _db;
        }

        // GET: api/ShoppingListItems
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ShoppingListItem>>> GetShoppingListItem()
        {            
            return await db.ShoppingListItems.ToListAsync();
        }

        // GET: api/ShoppingListItems/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ShoppingListItem>> GetShoppingListItem(int id)
        {
            var shoppingListItem = await db.ShoppingListItems.FindAsync(id);

            if (shoppingListItem == null)
            {
                return NotFound();
            }

            return shoppingListItem;
        }

        [HttpPut("{id}")]
        [Route("updatelistitem/{itemid}")]
        public async Task<ActionResult> UpdateListItem(int itemid, ShoppingListItem listItem)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { status = "error", message = "Form is invalid. Please check your entries and try again.", id = listItem.ItemId });
            }

            if (itemid != listItem.ItemId)
            {
                return BadRequest(new { status = "error", message = "Bad Request", id = listItem.ItemId });
            }

            try
            {
                db.Set<ShoppingListItem>().AddOrUpdate(listItem);
                // db.Entry(listItem).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Ok(listItem);
            }
            catch (Exception ex)
            {
                return NotFound(new { status = "error", message = "Item not found", id = listItem.ItemId });
            }
        }

        // PUT: api/ShoppingListItems/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]        
        public async Task<IActionResult> PutShoppingListItem(int id, ShoppingListItem shoppingListItem)
        {
            if (id != shoppingListItem.Id)
            {
                return BadRequest();
            }

            db.Entry(shoppingListItem).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ShoppingListItemExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost]
        [Route("createshoppinglistitems/{shoppinglistitems}")]
        public void CreateShoppingListItems(List<ShoppingListItem> shoppingListItems)
        {
            BulkInsert(shoppingListItems);
        }

        private void BulkInsert(List<ShoppingListItem> shoppingListItems)
        {
            db.ShoppingListItems.AddRange(shoppingListItems);
            db.SaveChangesAsync();
        }


        // POST: api/ShoppingListItems
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult<ShoppingListItem>> PostShoppingListItem(ShoppingListItem shoppingListItem)
        {
            try
            {
                        db.ShoppingListItems.Add(shoppingListItem);
                await db.SaveChangesAsync();

                return CreatedAtAction("GetShoppingListItem", new { id = shoppingListItem.Id }, shoppingListItem);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                return Ok();
            }
            
        }

        // DELETE: api/ShoppingListItems/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteShoppingListItem(int id)
        {
            var shoppingListItem = await db.ShoppingListItems.FindAsync(id);
            if (shoppingListItem == null)
            {
                return NotFound();
            }

            db.ShoppingListItems.Remove(shoppingListItem);
            await db.SaveChangesAsync();

            return NoContent();
        }

        private bool ShoppingListItemExists(int id)
        {
            return db.ShoppingListItems.Any(e => e.Id == id);
        }
    }
}
