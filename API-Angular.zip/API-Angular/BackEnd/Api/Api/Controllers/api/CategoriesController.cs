﻿using Api.Models;
using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Api.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class CategoriesController : ControllerBase
    {
        private readonly Entities db;
        public CategoriesController(Entities db)
        {
            this.db = db;
        }


        // GET: api/Categories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Category>>> GetCategories()
        {            
            return await db.Categories.ToListAsync();
        }

        // GET: api/Categories/5
        [HttpGet("{id}")]
        public ActionResult<Category> GetCategory(int id)
        {
            var category = db.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        [HttpGet]
        [Route("bybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(Category))]
        public async Task<ActionResult<IEnumerable<Category>>> GetByBusiness(int businessid)
        {
            return await db.Categories.Where(m => m.BusinessId == businessid && !m.SoftDelete && m.Visible).ToListAsync();
        }

        [HttpGet]
        [Route("adminbybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(Category))]
        public async Task<ActionResult<IEnumerable<Category>>> GetAdminByBusiness(int businessid)
        {
            return await db.Categories.Where(m => m.BusinessId == businessid).ToListAsync();
        }


        // PUT: api/Categories/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategory(int id, Category category)
        {
            if (id != category.Id)
            {
                return BadRequest();
            }

            db.Entry(category).State = (System.Data.Entity.EntityState)EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPut("{id}")]
        [Route("updatecategory/{id}")]
        public async Task<IActionResult> UpdateCategory(int id, Category category)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { Message = "Form is invalid. Please check your entries and try again.", Status = 2, Id = id });
            }

            if (id != category.Id)
            {
                return BadRequest(new { Message = "Bad Request", Status = 2, Id = id });
            }

            db.Entry(category).State = EntityState.Modified;
            try
            {
                await db.SaveChangesAsync();
                var message = "Category " + category.Name + " Saved";
                if (category.SoftDelete)
                {
                    message = "Category " + category.Name + " Deleted";
                }
                return Ok(new { Message = message, Status = 1, Id = id });
            }
            catch (Exception ex)
            {
                return NotFound(new { Status = "error", Message = "Category not found", Id = category.Id });
            }
        }

        // POST: api/Categories
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Category>> PostCategory(Category category)
        {
            var messageStatus = new MessageStatus();
            try
            {
                db.Categories.Add(category);
                await db.SaveChangesAsync();
                messageStatus.Message = "Category Saved";
                messageStatus.Status = "success";
                messageStatus.Id = category.Id;

                return Ok(messageStatus);
            }
            catch (System.Exception)
            {

                messageStatus.Message = "An error occurred";
                messageStatus.Status = "error";
                messageStatus.Id = category.Id;
                return Ok(messageStatus);
            }
        }

        [HttpPost]
        [Route("addcategory")]
        public async Task<ActionResult<Category>> AddCategory(Category category)
        {
            try
            {
                db.Categories.Add(category);
                await db.SaveChangesAsync();
                return Ok(new { Message = category.Name + " Added", Status = 1, id = category.Id });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "An error occured", Status = 2, Exception = ex.Message });
            }
        }
       
        // DELETE: api/Categories/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Category>> DeleteCategory(int id)
        {
            var category = await db.Categories.FindAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            db.Categories.Remove(category);
            await db.SaveChangesAsync();

            return category;
        }

        private bool CategoryExists(int id)
        {
            return db.Categories.Any(e => e.Id == id);
        }
    }
}

