﻿using Api.Models;
using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class SuppliersController : ControllerBase
    {
        private readonly Entities db;

        public SuppliersController(Entities db)
        {
            this.db = db;
        }

        [HttpGet]
        [Route("bybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(Supplier))]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetByBusiness(int businessid)
        {
            return await db.Suppliers.Where(m => m.BusinessId == businessid && !m.SoftDelete && m.Visible).ToListAsync();
        }

        [HttpGet]
        [Route("adminbybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(Supplier))]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetAdminByBusiness(int businessid)
        {
            return await db.Suppliers.Where(m => m.BusinessId == businessid).ToListAsync();
        }
                
        [HttpPost]
        public async Task<ActionResult<Supplier>> PostSupplier(Supplier supplier)
        {
            try
            {
                db.Suppliers.Add(supplier);
                await db.SaveChangesAsync();
                return Ok(new { Message = supplier.Name + " Added", Status = 1, id = supplier.Id });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "An error occured", Status = 2, Exception = ex.Message });
            }            
        }

        [HttpPut("{id}")]
        [Route("supplierupdate/{id}")]
        public async Task<ActionResult> SupplierUpdate(int id, Supplier supplier)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { Message = "Form is invalid. Please check your entries and try again.", Status = 2, Id = id });
            }

            if (id != supplier.Id)
            {
                return BadRequest(new { Message = "Bad Request", Status = 2, Id = id });
            }

            try
            {
                db.Entry(supplier).State = EntityState.Modified;
                await db.SaveChangesAsync();
                var message = "Supplier " + supplier.Name + " Saved";
                if (supplier.SoftDelete)
                {
                    message = "Supplier " + supplier.Name + " Deleted";
                }
                return Ok(new { Message = message, Status = 1, Id = id });
            }
            catch (Exception)
            {
                return NotFound(new { Status = "error", Message = "Supplier not found", Id = supplier.Id });
                
            }
        }

        private bool SupplierExists(int id)
        {
            return db.Suppliers.Any(e => e.Id == id);
        }
    }
}
