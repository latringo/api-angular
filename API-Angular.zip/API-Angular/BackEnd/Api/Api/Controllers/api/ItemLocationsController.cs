﻿using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers.api
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class ItemLocationsController : ControllerBase
    {
        private readonly Entities db;

        public ItemLocationsController(Entities db)
        {
            this.db = db;
        }

        // GET: api/ItemLocations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ItemLocation>>> GetItemLocations()
        {
            return await db.ItemLocations.ToListAsync();
        }

        // GET: api/ItemLocations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ItemLocation>> GetItemLocation(int id)
        {
            var itemLocation = await db.ItemLocations.FindAsync(id);

            if (itemLocation == null)
            {
                return NotFound();
            }

            return itemLocation;
        }

        [HttpGet]
        [Route("bybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(ItemLocation))]
        public async Task<ActionResult<IEnumerable<ItemLocation>>> GetByBusiness(int businessid)
        {
            return await db.ItemLocations.Where(m => m.BusinessId == businessid && !m.SoftDelete && m.Visible).ToListAsync();
        }

        [HttpGet]
        [Route("adminbybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(ItemLocation))]
        public async Task<ActionResult<IEnumerable<ItemLocation>>> GetAdminByBusiness(int businessid)
        {
            return await db.ItemLocations.Where(m => m.BusinessId == businessid).ToListAsync();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateItemLocation(int id, ItemLocation itemLocation)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { status = "error", message = "Form is invalid. Please check your entries and try again.", id = itemLocation.Id });
            }

            if (id != itemLocation.Id)
            {
                return BadRequest(new { status = "error", message = "Bad Request", id = itemLocation.Id });
            }
            db.Entry(itemLocation).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
                return Ok(new { status = "success", message = "Item updated", id = itemLocation.Id });
            }
            catch (Exception)
            {
                return NotFound(new { status = "error", message = "Item not found", id = itemLocation.Id });
            }
        }

        [HttpPut("{id}")]
        [Route("updatelocation/{id}")]
        public async Task<IActionResult> UpdateLocation(int id, ItemLocation location)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { Message = "Form is invalid. Please check your entries and try again.", Status = 2, Id = id });
            }

            if (id != location.Id)
            {
                return BadRequest(new { Message = "Bad Request", Status = 2, Id = id });
            }

            db.Entry(location).State = EntityState.Modified;
            try
            {
                await db.SaveChangesAsync();
                var message = "Item Location " + location.Name + " Saved";
                if (location.SoftDelete)
                {
                    message = "Item Location " + location.Name + " Deleted";
                }
                return Ok(new { Message = message, Status = 1, Id = id });
            }
            catch (Exception ex)
            {
                return NotFound(new { Status = "error", Message = "Item Location not found", Id = location.Id });
            }
        }

        [HttpPost]
        public async Task<ActionResult<ItemLocation>> PostItemLocation(ItemLocation itemLocation)
        {
            try
            {
                db.ItemLocations.Add(itemLocation);
                await db.SaveChangesAsync();
                return Ok(new { message = "Item saved", status = "success", id = itemLocation.Id });
            }
            catch (Exception)
            {
                return Ok(new { message = "An error occured", status = "error", id = itemLocation.Id });
            }
        }

        [HttpPost]
        [Route("addlocation")]
        public async Task<ActionResult<Category>> AddLocation(ItemLocation location)
        {
            try
            {
                db.ItemLocations.Add(location);
                await db.SaveChangesAsync();
                return Ok(new { Message = location.Name + " Added", Status = 1, id = location.Id });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "An error occured", Status = 2, Exception = ex.Message });
            }
        }
    }
}
