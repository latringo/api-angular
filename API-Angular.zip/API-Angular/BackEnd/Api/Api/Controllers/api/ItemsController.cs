﻿using Api.Models;
using Api.ViewModels;
using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;

namespace Api.Controllers.api
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {        
        private readonly Entities db;

        public ItemsController(Entities db)
        {
            this.db = db;
        }

        // GET: api/Items
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Item>>> GetItems()
        {
            var list = db.Items.Where(m => !m.SoftDelete && m.Visible).ToListAsync();
            return await list;
        }

        // GET: api/Items/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Item>> GetItem(int id)
        {
            var item = await db.Items
                .FindAsync(id);

            if (item == null)
            {
                return NotFound();
            }

            return item;
        }

        [HttpGet]
        [Route("getitemautocomplete/{businessid}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetQuickViewAutocompleteItems(int businessid)
        {
            var list = await db.Items
                 .Where(m => m.Category.BusinessId == businessid).ToListAsync();

            return list;
        }

        [HttpGet]
        [Route("getquickviews/{businessid}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetQuickViewsByBusiness(int businessid)
        {
            var list = await db.Items
                .Where(m => m.Category.BusinessId == businessid && m.QuickView && !m.SoftDelete && m.Visible).ToListAsync();

            return list;
        }

        [HttpGet]
        [Route("getquickviewcount/{businessid}")]
        public async Task<ActionResult<int>> GetQuickViewCount(int businessid)
        {
            var count = await db.Items.Where(m => m.QuickView && m.Category.BusinessId == businessid && m.SoftDelete == false).CountAsync();
            return count;
        }

        [HttpPut("{id}")]
        [Route("updateitem/{id}")]
        public async Task<IActionResult> UpdateItem(int id, Item item)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { Message = "Form is invalid. Please check your entries and try again.", Status = 2, Id = id });
            }

            if(id != item.Id)
            {
                return BadRequest(new { Message = "Bad Request", Status = 2, Id = id });
            }
            

            try
            {                
                db.Set<Item>().AddOrUpdate(item);
                await db.SaveChangesAsync();
                var message = "Item " + item.Name + " Saved";
                if (item.SoftDelete)
                {
                    message = "Item " + item.Name + " Deleted";
                }
                return Ok(new { Message = message, Status = 1, Id = id });
            }
            catch (Exception)
            {
                return NotFound(new { Status = "error", Message = "Item not found", Id = item.Id });
            }
        }

        [HttpPut()]
        [Route("updateitemonhand/{id}/{onhand}")]
        public async Task<IActionResult> UpdateItemOnHand(int id, Item item, int onhand)
        {
            if (!ModelState.IsValid)
            {
                return Ok(false);
            }

            if (id != item.Id)
            {
                return BadRequest(false);
            }
            db.Entry(item).State = EntityState.Modified;

            try
            {                
                await db.SaveChangesAsync();
                return Ok(item);
            }
            catch (Exception)
            {
                return NotFound(false);
            }
        }


        [HttpPut()]
        [Route("updateitemquickview/{id}")]
        public async Task<IActionResult> UpdateItemQuickView(int id, Item item)
        {
            if (!ModelState.IsValid)
            {
                return Ok(false);
            }

            if (id != item.Id)
            {
                return BadRequest(false);
            }
            db.Entry(item).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
                return Ok(true);
            }
            catch (Exception)
            {
                return NotFound(false);
            }
        }

        [HttpGet]
        [Route("bylocationcategory/{locationId}/{categoryId}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetByLocationCategory(int locationId, int categoryId)
        {
            return await db.Items
                .Where(m => m.ItemLocationId == locationId && m.CategoryId == categoryId && !m.SoftDelete && m.Visible)
                .OrderBy(m => m.Name)
                .ToListAsync();
        }

        [HttpGet]
        [Route("bylocationcategorybusiness/{locationId}/{categoryId}/{businessId}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetByLocationCategoryBusiness(int locationId, int categoryId, int businessId)
        {
            return await db.Items
                .Where(m => m.Category.BusinessId == businessId && m.ItemLocationId == locationId && m.CategoryId == categoryId && !m.SoftDelete && m.Visible)
                .OrderBy(m => m.Name)
                .ToListAsync();
        }

        [HttpGet]
        [Route("bybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetByBusiness(int businessid)
        {
            var itemList = await db.Items.Where(m => m.Category.BusinessId == businessid && !m.SoftDelete && m.Visible)
               .OrderBy(m => m.Category.Name).ThenBy(m => m.Name)
               .ToListAsync();
            return itemList;
            //return list;

        }

        [HttpGet]
        [Route("adminbybusiness/{businessid}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetAdminByBusiness(int businessid)
        {
            return await db.Items.Where(m => m.Category.BusinessId == businessid)
               .OrderBy(m => m.Category.Name).ThenBy(m => m.Name)
               .ToListAsync();

        }


        [HttpGet]
        [Route("bysupplier/{supplierid}")]
        [ProducesDefaultResponseType(typeof(Item))]
        public async Task<ActionResult<IEnumerable<Item>>> GetBySupplier(int supplierid)
        {
            return await db.Items
               .Where(m=>m.SupplierId == supplierid && !m.SoftDelete && m.Visible)
               .OrderBy(m => m.Category.Name)
               .ThenBy(m => m.Name)
               .ToListAsync();            
        }
        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutItem(int id, Item item)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { Entity = item, Message = "Form is invalid. Please check your entries and try again.", Status = 2 });
            }

            if (id != item.Id)
            {
                return BadRequest(new { Entity = item, Message = "Bad Request", Status = 2 });
            }


            db.Entry(item).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
                var message = "Item saved";
                if (item.SoftDelete)
                {
                    message = "Item deleted";
                }

                
                return Ok(new { Entity = item, Message = message, Status = 1});
            }
            catch (Exception)
            {
                return Ok(new { Entity = item, Message = "An error occured", Status = 2 });
            }
        }

        [HttpPost]
        [Route("additem")]
        public async Task<ActionResult<Item>> AddItem(Item item)
        {
            try
            {
                db.Items.Add(item);
                db.Entry(item.ItemLocation).State = EntityState.Unchanged;
                db.Entry(item.Supplier).State = EntityState.Unchanged;
                db.Entry(item.Category).State = EntityState.Unchanged;
                db.Entry(item.UnitOfMeasure).State = EntityState.Unchanged;

                await db.SaveChangesAsync();

                return Ok(new { Message = item.Name + " Added", Status = 1, id = item.Id });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "An error occured", Status = 2 });
            }

        }
        // POST: api/Items
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Item>> PostItem(Item item)
        {
            try
            {                
                db.Items.Add(item);
                await db.SaveChangesAsync();
                                
                return Ok(new { Message = item.Name + " Added", Status = 1, id = item.Id });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "An error occured", Status = 2 });
            }

        }
        
    }

}
