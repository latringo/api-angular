﻿using EFdotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers.api
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingListsController : ControllerBase
    {
        private readonly Entities db;

        public ShoppingListsController(Entities db)
        {
            this.db = db;
        }

        // GET: api/ShoppingLists
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ShoppingList>>> GetShoppingLists()
        {
            return await db.ShoppingLists.ToListAsync();
        }

        // GET: api/ShoppingLists/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ShoppingList>> GetShoppingList(int id)
        {
            var shoppingList = await db.ShoppingLists.FindAsync(id);

            if (shoppingList == null)
            {
                return NotFound();
            }

            return shoppingList;
        }

        [HttpGet]
        [Route("getcurrentshoppinglist")]
        public ActionResult<ShoppingList> GetCurrentShoppingList()
        {
            var startDate = DateTime.UtcNow.AddDays(-1);   //.Now.AddSeconds(-1);
            var endDate = DateTime.UtcNow;
            var shoppingList = db.ShoppingLists.Where(m => m.ListDate >= startDate && m.ListDate <= endDate)
                .OrderByDescending(m=>m.ListDate)
                .FirstOrDefault();
            return shoppingList;
        }

        [HttpGet]
        [Route("shoppinglistsbybusiness/{businessId}")]
        public async Task<ActionResult<IEnumerable<ShoppingList>>> GetShoppingLists(int businessId)
        {
            return await db.ShoppingLists
                .Where(m => m.BusinessId == businessId)
                .OrderBy(m => !m.Completed)
                .ThenByDescending(m => m.ListDate)
                .ToListAsync();
        }

        [HttpGet]
        [Route("shoppinglistcount/{businessId}")]
        public async Task<ActionResult<int>> GetShoppingListCount(int businessId)
        {
            return await db.ShoppingLists.Where(m => m.BusinessId == businessId).CountAsync();
        }

        [HttpGet]
        [Route("getbybusiness/{businessId}")]
        public async Task<ActionResult<IEnumerable<ShoppingList>>> GetShoppingListByBusiness(int businessId)
        {     
            
            return await db.ShoppingLists.Where(m => m.BusinessId == businessId)
                .OrderByDescending(m => m.ListDate).ToListAsync();
        }

        [HttpGet]
        [Route("getshoppingcartcount/{businessId}")]
        public async Task<ActionResult<int>> GetCartCount(int businessId)
        {
            var cartcount = await db.ShoppingLists.Where(m => m.BusinessId == businessId).CountAsync();
            return cartcount;
        }

        // PUT: api/ShoppingLists/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutShoppingList(int id, ShoppingList shoppingList)
        {
            if (id != shoppingList.Id)
            {
                return BadRequest();
            }

            db.Entry(shoppingList).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ShoppingListExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPut]
        [Route("saveshoppingcart/{shoppingList}")]
        public async Task<ActionResult<ShoppingList>> SaveCart(int id, ShoppingList shoppingList)
        {
            db.Entry(shoppingList).State = EntityState.Modified;
            await db.SaveChangesAsync();
            return shoppingList;
        }

        [HttpPut]
        [Route("saveshoppinglist/{id}/{shoppingList}")]
        public async Task<ActionResult<ShoppingList>> SaveShoppingList(int id, ShoppingList shoppingList)
        {
            if (id != shoppingList.Id)
            {
                return BadRequest();
            }

            db.Entry(shoppingList).State = EntityState.Modified;
            await db.SaveChangesAsync();
            return shoppingList;
        }

        // POST: api/ShoppingLists
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ShoppingList>> PostShoppingList(ShoppingList shoppingList)
        {
            
            try
            {
                db.ShoppingLists.Add(shoppingList);
                await db.SaveChangesAsync();
                return Ok(shoppingList);
            }
            catch (Exception ex)
            {
                var msg = ex.Message;
                if (!ShoppingListExists(shoppingList.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

        }

        // DELETE: api/ShoppingLists/5
        [HttpPut("{id}")]
        public async Task<ActionResult<ShoppingList>> DeleteShoppingList(int id, ShoppingList shoppingList)
        {
            if(id != shoppingList.Id)
            {
                return BadRequest();
            }

            db.Entry(shoppingList).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
                var response = new { status = "success", message = "Shopping Cart deleted", id = shoppingList.Id };
                return new JsonResult(response);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        private bool ShoppingListExists(int id)
        {
            return db.ShoppingLists.Any(e => e.Id == id);
        }
    }
}
